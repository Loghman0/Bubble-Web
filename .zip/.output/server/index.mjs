globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-08T15:25:50.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"16a3-v3ftO3I7Hb/ZFTqRumx54hzglas\"",
		"mtime": "2026-08-09T18:24:04.000Z",
		"size": 5795,
		"path": "../public/favicon.png"
	},
	"/assets/baits.index-CfHsUK2Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32b-yXClz5K3Rwj+QD6ZDe5/5a0/JAI\"",
		"mtime": "2026-08-15T11:53:14.096Z",
		"size": 811,
		"path": "../public/assets/baits.index-CfHsUK2Q.js"
	},
	"/assets/asset-42-JXiO3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cd-OqvAnVziiKW0xPF/mmF5HqLJ024\"",
		"mtime": "2026-08-15T11:53:14.095Z",
		"size": 973,
		"path": "../public/assets/asset-42-JXiO3.js"
	},
	"/assets/cards-CShZXPtU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bb3-nopSdYUo1KQVOZCB+js8xqmcOIg\"",
		"mtime": "2026-08-15T11:53:14.096Z",
		"size": 2995,
		"path": "../public/assets/cards-CShZXPtU.js"
	},
	"/assets/baits._slug-WRxHP5co.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"84c-FdjNwjqwCIMdc0HFZm99Ke/nooQ\"",
		"mtime": "2026-08-15T11:53:14.095Z",
		"size": 2124,
		"path": "../public/assets/baits._slug-WRxHP5co.js"
	},
	"/bubble.png": {
		"type": "image/png",
		"etag": "\"265dc-OWf6ASzCZ2HOFkRoK8edQaNhCeo\"",
		"mtime": "2026-08-09T19:22:04.000Z",
		"size": 157148,
		"path": "../public/bubble.png"
	},
	"/assets/eggs.index-Ciwbt2lp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"255-Z7uGtyUXull9WrhT/E6W4qYSU6I\"",
		"mtime": "2026-08-15T11:53:14.098Z",
		"size": 597,
		"path": "../public/assets/eggs.index-Ciwbt2lp.js"
	},
	"/assets/eggs._slug-C4uD0H_V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ef1-VoGRCf0PBwqQqB7zL0TYgR1CZU8\"",
		"mtime": "2026-08-15T11:53:14.097Z",
		"size": 3825,
		"path": "../public/assets/eggs._slug-C4uD0H_V.js"
	},
	"/assets/enchants.index-D--HBVEj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"520-KkZlpMxe5TC2kYxIMrc56FclE6Q\"",
		"mtime": "2026-08-15T11:53:14.099Z",
		"size": 1312,
		"path": "../public/assets/enchants.index-D--HBVEj.js"
	},
	"/assets/enchants._slug-DSzh34Cq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11b6-vuXc0lQG7cp065sv1afEtUF1NLs\"",
		"mtime": "2026-08-15T11:53:14.098Z",
		"size": 4534,
		"path": "../public/assets/enchants._slug-DSzh34Cq.js"
	},
	"/assets/faq-BLeCM6CC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e24-X2h61rrjmgEkfmJJoM5NcZZJTR0\"",
		"mtime": "2026-08-15T11:53:14.099Z",
		"size": 7716,
		"path": "../public/assets/faq-BLeCM6CC.js"
	},
	"/assets/createLucideIcon-Cgt1V5aE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a5-CDMX127y0FE2dX9oyOJoYJF47mE\"",
		"mtime": "2026-08-15T11:53:14.097Z",
		"size": 1189,
		"path": "../public/assets/createLucideIcon-Cgt1V5aE.js"
	},
	"/assets/features-B5rn2qQB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1179-O84lwf2YhufH8riMB067/a0/KUE\"",
		"mtime": "2026-08-15T11:53:14.099Z",
		"size": 4473,
		"path": "../public/assets/features-B5rn2qQB.js"
	},
	"/assets/fish.index-BaUagaH8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d41-f6GcCaorVLkeGoxgbOxVXpiofGo\"",
		"mtime": "2026-08-15T11:53:14.100Z",
		"size": 3393,
		"path": "../public/assets/fish.index-BaUagaH8.js"
	},
	"/assets/fish._slug-BeNWysLz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7e-aNDEMjWnUOqb78Ke6BLJYG9A9zA\"",
		"mtime": "2026-08-15T11:53:14.099Z",
		"size": 3198,
		"path": "../public/assets/fish._slug-BeNWysLz.js"
	},
	"/assets/game-format-C7SNMZ2d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"195-vx4hhS+zHoVtrkJmxPbLk1rp8m8\"",
		"mtime": "2026-08-15T11:53:14.100Z",
		"size": 405,
		"path": "../public/assets/game-format-C7SNMZ2d.js"
	},
	"/assets/input-C5wCZI5w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ed-RdAXKIfmCpdQmtkSRLG8NPZfVZY\"",
		"mtime": "2026-08-15T11:53:14.100Z",
		"size": 749,
		"path": "../public/assets/input-C5wCZI5w.js"
	},
	"/assets/leaderboard-DK0A7Wvv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4dea-FyFB4GW3jEJ9FPV8vD8hoe1W7S0\"",
		"mtime": "2026-08-15T11:53:14.101Z",
		"size": 19946,
		"path": "../public/assets/leaderboard-DK0A7Wvv.js"
	},
	"/assets/OceanBackdrop-CGeS_onY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"679-Obw4BbqJuCvd3FkYjorYdchRXtw\"",
		"mtime": "2026-08-15T11:53:14.095Z",
		"size": 1657,
		"path": "../public/assets/OceanBackdrop-CGeS_onY.js"
	},
	"/assets/link-DINiT5xD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54f0-FTRhfIf4VeqMlILG1EjHYz5YJYA\"",
		"mtime": "2026-08-15T11:53:14.101Z",
		"size": 21744,
		"path": "../public/assets/link-DINiT5xD.js"
	},
	"/assets/pets.index-BCcdXS-a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"290-WTfCdnVXm2/nIpWqNjIeNI3yyLI\"",
		"mtime": "2026-08-15T11:53:14.102Z",
		"size": 656,
		"path": "../public/assets/pets.index-BCcdXS-a.js"
	},
	"/assets/pets._slug-CxJksiZm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"958-6L/MzMlW8Z3w5eY63yq4clI2BN4\"",
		"mtime": "2026-08-15T11:53:14.102Z",
		"size": 2392,
		"path": "../public/assets/pets._slug-CxJksiZm.js"
	},
	"/assets/primitives-DzUDVYA5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7f6-a57Hi7wwh8/Pr+whiMZmLoki3Io\"",
		"mtime": "2026-08-15T11:53:14.102Z",
		"size": 124918,
		"path": "../public/assets/primitives-DzUDVYA5.js"
	},
	"/assets/index-CcpPu-DY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a31c-alFLoUGojKYrkqCfWx0pllKxuxo\"",
		"mtime": "2026-08-15T11:53:14.094Z",
		"size": 500508,
		"path": "../public/assets/index-CcpPu-DY.js"
	},
	"/assets/privacy-DtYAFEce.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"655-1TRowibWs5VrVFtfpVtRxIhP5vM\"",
		"mtime": "2026-08-15T11:53:14.102Z",
		"size": 1621,
		"path": "../public/assets/privacy-DtYAFEce.js"
	},
	"/assets/react-dom-BRNPAwij.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd8-ZcVEjawoxRmm7mq6TDPLp9HzEI8\"",
		"mtime": "2026-08-15T11:53:14.103Z",
		"size": 3544,
		"path": "../public/assets/react-dom-BRNPAwij.js"
	},
	"/assets/rods.index-BbL4jMt3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"310-wT9p8HSo40yhJbgePYyiEZz9Qmk\"",
		"mtime": "2026-08-15T11:53:14.103Z",
		"size": 784,
		"path": "../public/assets/rods.index-BbL4jMt3.js"
	},
	"/assets/rods._slug-YwaguX_N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cb8-sB/4R1SVQV9QJd/pBqfjmtG1l+U\"",
		"mtime": "2026-08-15T11:53:14.103Z",
		"size": 3256,
		"path": "../public/assets/rods._slug-YwaguX_N.js"
	},
	"/assets/routes-3YsVXmlY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b86-P5mx0C0B7pH+NXMf2FxkLlEilwk\"",
		"mtime": "2026-08-15T11:53:14.104Z",
		"size": 7046,
		"path": "../public/assets/routes-3YsVXmlY.js"
	},
	"/assets/select-D-SZqp4v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5733-GG2t3M7COJxU2IYnwu0FB42yjIc\"",
		"mtime": "2026-08-15T11:53:14.104Z",
		"size": 22323,
		"path": "../public/assets/select-D-SZqp4v.js"
	},
	"/assets/sparkles-C3WlmzSQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-uCGvOVkj1Z47w/Fq82IbEvHC3ac\"",
		"mtime": "2026-08-15T11:53:14.104Z",
		"size": 494,
		"path": "../public/assets/sparkles-C3WlmzSQ.js"
	},
	"/assets/terms-uZYipadI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66d-asS3GRxX+JmnnV5iRm6oXQR5P3E\"",
		"mtime": "2026-08-15T11:53:14.105Z",
		"size": 1645,
		"path": "../public/assets/terms-uZYipadI.js"
	},
	"/assets/utils-BFmSEvC8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b8f-Kzes1hAdcxXDwcBTRUValBaVJws\"",
		"mtime": "2026-08-15T11:53:14.105Z",
		"size": 35727,
		"path": "../public/assets/utils-BFmSEvC8.js"
	},
	"/assets/wand-sparkles-BMfJkCsw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"679-aOo+Mzlu2DQCuJk73pjGTDG9riw\"",
		"mtime": "2026-08-15T11:53:14.105Z",
		"size": 1657,
		"path": "../public/assets/wand-sparkles-BMfJkCsw.js"
	},
	"/assets/styles-DIiCopOD.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17f6d-W6nCCyGwIL1so7iC1LMbjdQ8UJQ\"",
		"mtime": "2026-08-15T11:53:14.106Z",
		"size": 98157,
		"path": "../public/assets/styles-DIiCopOD.css"
	},
	"/assets/wiki.index-DyPoWFiX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10ab-ANxso5QBKRaozvvVBAvYH6h+n0g\"",
		"mtime": "2026-08-15T11:53:14.106Z",
		"size": 4267,
		"path": "../public/assets/wiki.index-DyPoWFiX.js"
	},
	"/assets/wiki._slug-DSFg10vG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e76-z8HKSepqeZ7EINkOcA/7E+q9OEQ\"",
		"mtime": "2026-08-15T11:53:14.105Z",
		"size": 3702,
		"path": "../public/assets/wiki._slug-DSFg10vG.js"
	},
	"/assets/baits/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/baits/.gitkeep"
	},
	"/assets/baits/cricket.png": {
		"type": "image/png",
		"etag": "\"27743-fllJpsLOd0Pk/VO/NiKjm965T5I\"",
		"mtime": "2026-08-04T08:31:04.000Z",
		"size": 161603,
		"path": "../public/assets/baits/cricket.png"
	},
	"/assets/baits/crystal_shrimp.png": {
		"type": "image/png",
		"etag": "\"2870d-KqMQG3ETRQvci+IjmSBkvTDupjo\"",
		"mtime": "2026-08-04T08:31:20.000Z",
		"size": 165645,
		"path": "../public/assets/baits/crystal_shrimp.png"
	},
	"/assets/baits/dragon_blood.png": {
		"type": "image/png",
		"etag": "\"1c07b-dJfgta/+tM2X2YmY0yHEOowlrpU\"",
		"mtime": "2026-08-04T08:31:38.000Z",
		"size": 114811,
		"path": "../public/assets/baits/dragon_blood.png"
	},
	"/assets/baits/enchanted_worm.png": {
		"type": "image/png",
		"etag": "\"30ca9-qyk+Tjz2mM07tJgRBtFqienVWYk\"",
		"mtime": "2026-08-04T08:31:56.000Z",
		"size": 199849,
		"path": "../public/assets/baits/enchanted_worm.png"
	},
	"/assets/baits/leech.png": {
		"type": "image/png",
		"etag": "\"21d8b-p3N4P3U3eU5SnSLRzgxaznLiu90\"",
		"mtime": "2026-08-04T08:32:34.000Z",
		"size": 138635,
		"path": "../public/assets/baits/leech.png"
	},
	"/assets/baits/gold_worm.png": {
		"type": "image/png",
		"etag": "\"2a629-H9gIyQ4EBAH1poQC0xFcHYEVXlA\"",
		"mtime": "2026-08-04T08:32:14.000Z",
		"size": 173609,
		"path": "../public/assets/baits/gold_worm.png"
	},
	"/assets/baits/magical_dust.png": {
		"type": "image/png",
		"etag": "\"313cc-j4sm72t0BCG2gBtjqSz1B04JvKs\"",
		"mtime": "2026-08-04T08:33:02.000Z",
		"size": 201676,
		"path": "../public/assets/baits/magical_dust.png"
	},
	"/assets/baits/magic_worm.png": {
		"type": "image/png",
		"etag": "\"2cc1f-2FoIpEFDrRLjmSmCWi8kAsLo1NU\"",
		"mtime": "2026-08-04T08:32:46.000Z",
		"size": 183327,
		"path": "../public/assets/baits/magic_worm.png"
	},
	"/assets/baits/squid_strip.png": {
		"type": "image/png",
		"etag": "\"17aa9-mRJOvlJoOT4OIUfegJYf/Iunex4\"",
		"mtime": "2026-08-04T08:33:46.000Z",
		"size": 96937,
		"path": "../public/assets/baits/squid_strip.png"
	},
	"/assets/baits/shrimp.png": {
		"type": "image/png",
		"etag": "\"20a57-wn3rK5B3PXFGKGmyCBiHBK54NiA\"",
		"mtime": "2026-08-04T08:33:14.000Z",
		"size": 133719,
		"path": "../public/assets/baits/shrimp.png"
	},
	"/assets/baits/starlight_dust.png": {
		"type": "image/png",
		"etag": "\"275d2-RdEKOKzfGfo9SiwIvUWTlaBgOkE\"",
		"mtime": "2026-08-04T08:34:00.000Z",
		"size": 161234,
		"path": "../public/assets/baits/starlight_dust.png"
	},
	"/assets/currencies/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/currencies/.gitkeep"
	},
	"/assets/baits/worm.png": {
		"type": "image/png",
		"etag": "\"3b84c-tXphlu9bPUoiXyonjAtG6KGurt4\"",
		"mtime": "2026-08-04T08:34:14.000Z",
		"size": 243788,
		"path": "../public/assets/baits/worm.png"
	},
	"/assets/currencies/bubble_coin.png": {
		"type": "image/png",
		"etag": "\"34dd1-btRg4T7+elTXDM6TSvJ6auy6Znk\"",
		"mtime": "2026-08-05T04:52:22.000Z",
		"size": 216529,
		"path": "../public/assets/currencies/bubble_coin.png"
	},
	"/assets/eggs/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/eggs/.gitkeep"
	},
	"/assets/currencies/ancient_coin.png": {
		"type": "image/png",
		"etag": "\"5d5df-kQaWBKGagn+w6+3gyKVqSsyiXsU\"",
		"mtime": "2026-08-07T06:53:52.000Z",
		"size": 382431,
		"path": "../public/assets/currencies/ancient_coin.png"
	},
	"/assets/currencies/bubble_gem.png": {
		"type": "image/png",
		"etag": "\"35a20-zVk51aybO7GiCJ6iPOEgrysPBjk\"",
		"mtime": "2026-08-05T04:52:34.000Z",
		"size": 219680,
		"path": "../public/assets/currencies/bubble_gem.png"
	},
	"/assets/eggs/common_egg.png": {
		"type": "image/png",
		"etag": "\"18366-1T8fQgc7LYwoYKhn5oYGrOWYWmY\"",
		"mtime": "2026-08-07T06:54:26.000Z",
		"size": 99174,
		"path": "../public/assets/eggs/common_egg.png"
	},
	"/assets/enchantments/double_hook.png": {
		"type": "image/png",
		"etag": "\"40c8a-2X+I/G30OYili+H1AM2zT5ByIWo\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 265354,
		"path": "../public/assets/enchantments/double_hook.png"
	},
	"/assets/eggs/ancient_egg.png": {
		"type": "image/png",
		"etag": "\"32e51-X1qAww26ow8ZJ94zr5gmsPwt5so\"",
		"mtime": "2026-08-07T06:54:02.000Z",
		"size": 208465,
		"path": "../public/assets/eggs/ancient_egg.png"
	},
	"/assets/enchantments/coin_blessing.png": {
		"type": "image/png",
		"etag": "\"32ef2-965KiYvFl9MmmBynKdF5tqCNDnk\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 208626,
		"path": "../public/assets/enchantments/coin_blessing.png"
	},
	"/assets/eggs/rare_egg.png": {
		"type": "image/png",
		"etag": "\"35084-lRA75fefSAFDUj5Lh9UEVopJdak\"",
		"mtime": "2026-08-07T06:54:14.000Z",
		"size": 217220,
		"path": "../public/assets/eggs/rare_egg.png"
	},
	"/assets/enchantments/efficient_line.png": {
		"type": "image/png",
		"etag": "\"591df-49+8a5wq2bH5Z4/J2nJEOxJ/eG4\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 365023,
		"path": "../public/assets/enchantments/efficient_line.png"
	},
	"/assets/enchantments/experienced_angler.png": {
		"type": "image/png",
		"etag": "\"34228-5uw/E928XQNS4nJClIT2+BLRX7I\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 213544,
		"path": "../public/assets/enchantments/experienced_angler.png"
	},
	"/assets/enchantments/gem_hunter.png": {
		"type": "image/png",
		"etag": "\"3c9cc-hkQv9lQK0dquyKjWYKNlUwSInEE\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 248268,
		"path": "../public/assets/enchantments/gem_hunter.png"
	},
	"/assets/enchantments/lucky_catch.png": {
		"type": "image/png",
		"etag": "\"23986-KKMRCT8nWU6SEi+hz9Sx3DbLQ4s\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 145798,
		"path": "../public/assets/enchantments/lucky_catch.png"
	},
	"/assets/enchantments/treasure_hunter.png": {
		"type": "image/png",
		"etag": "\"2f440-gEZk+MYbWQwQLLhgZzfH1IEkwZA\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 193600,
		"path": "../public/assets/enchantments/treasure_hunter.png"
	},
	"/assets/enchantments/museum_instinct.png": {
		"type": "image/png",
		"etag": "\"3b003-SJRQ9NAp6p6oLElx68Sv245bw2E\"",
		"mtime": "2026-08-09T15:11:54.000Z",
		"size": 241667,
		"path": "../public/assets/enchantments/museum_instinct.png"
	},
	"/assets/pets/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/pets/.gitkeep"
	},
	"/assets/pets/capybara.png": {
		"type": "image/png",
		"etag": "\"29183-BYolV2xojuAdTo9mJdCGLQPMO5Y\"",
		"mtime": "2026-08-15T11:00:12.667Z",
		"size": 168323,
		"path": "../public/assets/pets/capybara.png"
	},
	"/assets/pets/axolotl.png": {
		"type": "image/png",
		"etag": "\"2b753-zpcazLIzvArJJKx9R50CiIr3IqQ\"",
		"mtime": "2026-08-04T08:27:24.000Z",
		"size": 178003,
		"path": "../public/assets/pets/axolotl.png"
	},
	"/assets/pets/dog.png": {
		"type": "image/png",
		"etag": "\"305d2-ITReBaKBhzn4kr7X3Q7JR3ZB/kw\"",
		"mtime": "2026-08-04T08:28:00.000Z",
		"size": 198098,
		"path": "../public/assets/pets/dog.png"
	},
	"/assets/pets/cat.png": {
		"type": "image/png",
		"etag": "\"383fd-oZZOaJdGyh3BzbRCY6ViGAE6ecE\"",
		"mtime": "2026-08-04T08:27:42.000Z",
		"size": 230397,
		"path": "../public/assets/pets/cat.png"
	},
	"/assets/pets/dragon.png": {
		"type": "image/png",
		"etag": "\"35d80-BzQtzed1sajzEwzWQpM29MQ1+v8\"",
		"mtime": "2026-08-04T08:28:16.000Z",
		"size": 220544,
		"path": "../public/assets/pets/dragon.png"
	},
	"/assets/pets/kitsune_pup.png": {
		"type": "image/png",
		"etag": "\"3ca10-KH2GAZJMn8TOxkHFUGjHObV0rLY\"",
		"mtime": "2026-08-15T11:00:12.975Z",
		"size": 248336,
		"path": "../public/assets/pets/kitsune_pup.png"
	},
	"/assets/pets/kraken_hatchling.png": {
		"type": "image/png",
		"etag": "\"1f5ec-dOdrl/+EjtpMAz2ZTN7tmUNIvfo\"",
		"mtime": "2026-08-04T08:28:36.000Z",
		"size": 128492,
		"path": "../public/assets/pets/kraken_hatchling.png"
	},
	"/assets/pets/monoloth_golem.png": {
		"type": "image/png",
		"etag": "\"4d94c-IW47zz81mHYE1CPEmOhxnximGxw\"",
		"mtime": "2026-08-15T11:00:12.935Z",
		"size": 317772,
		"path": "../public/assets/pets/monoloth_golem.png"
	},
	"/assets/pets/otter.png": {
		"type": "image/png",
		"etag": "\"36367-2N/4mXbZBRbnzk+HIdf6vyYX7g4\"",
		"mtime": "2026-08-04T08:28:56.000Z",
		"size": 222055,
		"path": "../public/assets/pets/otter.png"
	},
	"/assets/pets/parrot.png": {
		"type": "image/png",
		"etag": "\"2cb52-BZVcz80tv00zIOV/Tvw09Q6s7j0\"",
		"mtime": "2026-08-07T06:53:20.000Z",
		"size": 183122,
		"path": "../public/assets/pets/parrot.png"
	},
	"/assets/pets/penguin.png": {
		"type": "image/png",
		"etag": "\"1cf24-J/fYMNoUe1ljLr4tfzG5D8B4i/Q\"",
		"mtime": "2026-08-04T08:29:14.000Z",
		"size": 118564,
		"path": "../public/assets/pets/penguin.png"
	},
	"/assets/pets/seal.png": {
		"type": "image/png",
		"etag": "\"2deed-JeUA2B28uk+ix8mbOHUZz+Tlo6E\"",
		"mtime": "2026-08-04T08:29:50.000Z",
		"size": 188141,
		"path": "../public/assets/pets/seal.png"
	},
	"/assets/rods/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/rods/.gitkeep"
	},
	"/assets/pets/sea_spirit.png": {
		"type": "image/png",
		"etag": "\"1a7f7-3ZzDr1t2rvqn+gRZlVosipje9Fw\"",
		"mtime": "2026-08-04T08:29:32.000Z",
		"size": 108535,
		"path": "../public/assets/pets/sea_spirit.png"
	},
	"/assets/pets/shark_pup.png": {
		"type": "image/png",
		"etag": "\"1e065-/ZP0G/BBi9MMeDPdG7vDKIkxptI\"",
		"mtime": "2026-08-04T08:30:06.000Z",
		"size": 122981,
		"path": "../public/assets/pets/shark_pup.png"
	},
	"/assets/pets/void_wisp.png": {
		"type": "image/png",
		"etag": "\"227d2-0IrLEx6ROv0nhV1Rl9ggU4GbMac\"",
		"mtime": "2026-08-04T08:27:06.000Z",
		"size": 141266,
		"path": "../public/assets/pets/void_wisp.png"
	},
	"/assets/rods/bamboo_rod.png": {
		"type": "image/png",
		"etag": "\"241eb-53GxO5jzNKXkH73P5YrBDwx8I4s\"",
		"mtime": "2026-08-04T05:54:32.000Z",
		"size": 147947,
		"path": "../public/assets/rods/bamboo_rod.png"
	},
	"/assets/rods/coral_rod.png": {
		"type": "image/png",
		"etag": "\"18007-GLlNkAv2TZaBwb7suXO7uBy+ocI\"",
		"mtime": "2026-08-04T05:54:40.000Z",
		"size": 98311,
		"path": "../public/assets/rods/coral_rod.png"
	},
	"/assets/rods/gold_rod.png": {
		"type": "image/png",
		"etag": "\"1a8ce-szH0QMCo9c+zUl8J4vRI7t4RFpU\"",
		"mtime": "2026-08-04T05:55:50.000Z",
		"size": 108750,
		"path": "../public/assets/rods/gold_rod.png"
	},
	"/assets/rods/iron_rod.png": {
		"type": "image/png",
		"etag": "\"2330b-eEP1BtvRcBCKa+nooNW5H4ByXyY\"",
		"mtime": "2026-08-04T05:55:18.000Z",
		"size": 144139,
		"path": "../public/assets/rods/iron_rod.png"
	},
	"/assets/rods/reinforced_rod.png": {
		"type": "image/png",
		"etag": "\"19c4f-xZTs9xuoMfT1Ro6ySjM8qIeRHpI\"",
		"mtime": "2026-08-04T05:55:30.000Z",
		"size": 105551,
		"path": "../public/assets/rods/reinforced_rod.png"
	},
	"/assets/fish/.gitkeep": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
		"mtime": "2026-08-08T11:32:44.000Z",
		"size": 0,
		"path": "../public/assets/fish/.gitkeep"
	},
	"/assets/rods/wood_rod.png": {
		"type": "image/png",
		"etag": "\"16f54-daPLHSJrje9GEcj84Ew5y6tCmyQ\"",
		"mtime": "2026-08-04T05:55:00.000Z",
		"size": 94036,
		"path": "../public/assets/rods/wood_rod.png"
	},
	"/assets/fish/abyssal_bell_jelly.png": {
		"type": "image/png",
		"etag": "\"28711-qeHHIsVRhvoKWYM2cCKxoJC653M\"",
		"mtime": "2026-08-15T10:58:27.776Z",
		"size": 165649,
		"path": "../public/assets/fish/abyssal_bell_jelly.png"
	},
	"/assets/rods/steel_rod.png": {
		"type": "image/png",
		"etag": "\"1adb8-uZU47Hfggq5lOo2uQ3pG8FMIqQs\"",
		"mtime": "2026-08-04T05:55:40.000Z",
		"size": 110008,
		"path": "../public/assets/rods/steel_rod.png"
	},
	"/assets/fish/abyssal_leviathan_pup.png": {
		"type": "image/png",
		"etag": "\"365cf-k/lXSsyAapc8LHWSYQ/JP3j7Yfk\"",
		"mtime": "2026-08-04T08:14:30.000Z",
		"size": 222671,
		"path": "../public/assets/fish/abyssal_leviathan_pup.png"
	},
	"/assets/fish/abyssal_goliath.png": {
		"type": "image/png",
		"etag": "\"500f4-VM8so0EPQL1if1vj9pVn+9SSD5E\"",
		"mtime": "2026-08-15T10:58:27.876Z",
		"size": 327924,
		"path": "../public/assets/fish/abyssal_goliath.png"
	},
	"/assets/fish/abyssal_maw.png": {
		"type": "image/png",
		"etag": "\"33ea1-LpwsQq3tP1NztJKMNzDvlDL7EVY\"",
		"mtime": "2026-08-08T02:32:28.000Z",
		"size": 212641,
		"path": "../public/assets/fish/abyssal_maw.png"
	},
	"/assets/fish/anglerfish.png": {
		"type": "image/png",
		"etag": "\"320e8-J9dYBTwuMPwoUHVsEDonV/Img5Y\"",
		"mtime": "2026-08-04T10:05:18.000Z",
		"size": 205032,
		"path": "../public/assets/fish/anglerfish.png"
	},
	"/assets/fish/archer_fish.png": {
		"type": "image/png",
		"etag": "\"19fac-RxydZVj0+VkNUlunYvyz5Gq2zsI\"",
		"mtime": "2026-08-15T10:58:27.802Z",
		"size": 106412,
		"path": "../public/assets/fish/archer_fish.png"
	},
	"/assets/rods/cosmic_rod.png": {
		"type": "image/png",
		"etag": "\"161da6-kdxBqJTvQXjpSkDsPLusxrRM3Ik\"",
		"mtime": "2026-08-04T03:52:00.000Z",
		"size": 1449382,
		"path": "../public/assets/rods/cosmic_rod.png"
	},
	"/assets/rods/dragon_rod.png": {
		"type": "image/png",
		"etag": "\"16ebc7-205xvZeMLHoltFq+Q+OtQx/qyjY\"",
		"mtime": "2026-08-04T03:49:06.000Z",
		"size": 1502151,
		"path": "../public/assets/rods/dragon_rod.png"
	},
	"/assets/fish/arctic_char.png": {
		"type": "image/png",
		"etag": "\"24847-g3e1CaZevSPY9ybGzBajOyrr2MQ\"",
		"mtime": "2026-08-04T10:05:42.000Z",
		"size": 149575,
		"path": "../public/assets/fish/arctic_char.png"
	},
	"/assets/fish/astral_leviathan.png": {
		"type": "image/png",
		"etag": "\"35206-Ht9Q2ziflx/8XboNtBbRSY3SfT0\"",
		"mtime": "2026-08-04T08:14:56.000Z",
		"size": 217606,
		"path": "../public/assets/fish/astral_leviathan.png"
	},
	"/assets/fish/astral_star_ray.png": {
		"type": "image/png",
		"etag": "\"2e206-KTbpxt8QhgDk7paaiKKc89bU7Bo\"",
		"mtime": "2026-08-15T10:58:27.840Z",
		"size": 188934,
		"path": "../public/assets/fish/astral_star_ray.png"
	},
	"/assets/fish/astral_weaver.png": {
		"type": "image/png",
		"etag": "\"2e08a-hoJgeRuGmhA+AILc6NhL5TgEYkc\"",
		"mtime": "2026-08-15T10:59:21.311Z",
		"size": 188554,
		"path": "../public/assets/fish/astral_weaver.png"
	},
	"/assets/fish/aurora_icefish.png": {
		"type": "image/png",
		"etag": "\"2a727-CKqJMtqo1RXbGnNKbST8PafuaTM\"",
		"mtime": "2026-08-04T08:15:18.000Z",
		"size": 173863,
		"path": "../public/assets/fish/aurora_icefish.png"
	},
	"/assets/fish/bichir.png": {
		"type": "image/png",
		"etag": "\"2aca4-bfRuD2+ukuNn2zRIO/wcVNq7xdk\"",
		"mtime": "2026-08-15T10:59:20.330Z",
		"size": 175268,
		"path": "../public/assets/fish/bichir.png"
	},
	"/assets/fish/bioluminescent_jelly.png": {
		"type": "image/png",
		"etag": "\"2b714-8BdkezabWfY6pMUSIVGWAgzl/2I\"",
		"mtime": "2026-08-08T02:32:28.000Z",
		"size": 177940,
		"path": "../public/assets/fish/bioluminescent_jelly.png"
	},
	"/assets/fish/bioluminescent_shark.png": {
		"type": "image/png",
		"etag": "\"29f1d-40NyED/KAN+hJxlNTjYiw28kvxQ\"",
		"mtime": "2026-08-15T10:59:20.435Z",
		"size": 171805,
		"path": "../public/assets/fish/bioluminescent_shark.png"
	},
	"/assets/fish/bluefin_tuna.png": {
		"type": "image/png",
		"etag": "\"29c90-V9txHu1eYap+kPLknOn0ctdhnxg\"",
		"mtime": "2026-08-04T10:06:20.000Z",
		"size": 171152,
		"path": "../public/assets/fish/bluefin_tuna.png"
	},
	"/assets/fish/bitterling.png": {
		"type": "image/png",
		"etag": "\"23b99-/dGImHs1daqSIGrb69sZgcIB2kw\"",
		"mtime": "2026-08-15T10:59:20.319Z",
		"size": 146329,
		"path": "../public/assets/fish/bitterling.png"
	},
	"/assets/fish/bluegill.png": {
		"type": "image/png",
		"etag": "\"3fbbd-iXGPcd1xdLhmAIYt9R3GHhQL+4o\"",
		"mtime": "2026-08-04T10:06:40.000Z",
		"size": 261053,
		"path": "../public/assets/fish/bluegill.png"
	},
	"/assets/fish/bog_witchs_familiar.png": {
		"type": "image/png",
		"etag": "\"313e1-p0OAl2mmvpovKt0FXqJ8H03YLkA\"",
		"mtime": "2026-08-04T08:15:26.000Z",
		"size": 201697,
		"path": "../public/assets/fish/bog_witchs_familiar.png"
	},
	"/assets/fish/brown_trout.png": {
		"type": "image/png",
		"etag": "\"2c22a-rA5hCkZfqpBvuXENjsc13wrfeVc\"",
		"mtime": "2026-08-15T10:59:20.380Z",
		"size": 180778,
		"path": "../public/assets/fish/brown_trout.png"
	},
	"/assets/fish/blue_marlin.png": {
		"type": "image/png",
		"etag": "\"2e1db-tr2KV7gZFNAo9ojNtSShUsVzSfM\"",
		"mtime": "2026-08-04T10:06:00.000Z",
		"size": 188891,
		"path": "../public/assets/fish/blue_marlin.png"
	},
	"/assets/fish/bog_eel.png": {
		"type": "image/png",
		"etag": "\"2f3f7-q/OURZdPYvvst1SbSAFkNSQG3mc\"",
		"mtime": "2026-08-04T10:07:00.000Z",
		"size": 193527,
		"path": "../public/assets/fish/bog_eel.png"
	},
	"/assets/fish/cave_blindfish.png": {
		"type": "image/png",
		"etag": "\"21058-ElGEkC6j+g8IswkMHjoRV4VmohQ\"",
		"mtime": "2026-08-08T02:33:20.000Z",
		"size": 135256,
		"path": "../public/assets/fish/cave_blindfish.png"
	},
	"/assets/fish/channel_catfish.png": {
		"type": "image/png",
		"etag": "\"21142-e+FjgfLEhD9JzFZjpFV2GYQBNPg\"",
		"mtime": "2026-08-04T10:07:18.000Z",
		"size": 135490,
		"path": "../public/assets/fish/channel_catfish.png"
	},
	"/assets/fish/cherry_barb.png": {
		"type": "image/png",
		"etag": "\"21093-rDz4v55pK9H23CvsCmZoSQ38AWY\"",
		"mtime": "2026-08-15T10:59:23.980Z",
		"size": 135315,
		"path": "../public/assets/fish/cherry_barb.png"
	},
	"/assets/fish/celestial_leviathan.png": {
		"type": "image/png",
		"etag": "\"2bf7c-BjFSAX6n9k5+3D/z0ZiQWWmWvSU\"",
		"mtime": "2026-08-04T08:15:36.000Z",
		"size": 180092,
		"path": "../public/assets/fish/celestial_leviathan.png"
	},
	"/assets/fish/chronos_wyrm.png": {
		"type": "image/png",
		"etag": "\"2fbd0-+LoDaud7E5mxxR7MM0o4HsYbzDk\"",
		"mtime": "2026-08-08T02:33:20.000Z",
		"size": 195536,
		"path": "../public/assets/fish/chronos_wyrm.png"
	},
	"/assets/fish/cloudfin_ray.png": {
		"type": "image/png",
		"etag": "\"1f3cf-DPUvcOQPaDCD95kKkBWaO/iXrcE\"",
		"mtime": "2026-08-04T10:07:36.000Z",
		"size": 127951,
		"path": "../public/assets/fish/cloudfin_ray.png"
	},
	"/assets/fish/clownfish.png": {
		"type": "image/png",
		"etag": "\"2cba7-qEsmOZnFHsZzlfyxezlkBKq7O3Q\"",
		"mtime": "2026-08-04T10:07:54.000Z",
		"size": 183207,
		"path": "../public/assets/fish/clownfish.png"
	},
	"/assets/fish/comet_tail_koi.png": {
		"type": "image/png",
		"etag": "\"1e61a-Hm3PMfNul/23sr/45bM2/pc6vD4\"",
		"mtime": "2026-08-15T10:59:24.085Z",
		"size": 124442,
		"path": "../public/assets/fish/comet_tail_koi.png"
	},
	"/assets/fish/common_shiner.png": {
		"type": "image/png",
		"etag": "\"27bbd-lWrtCzR6I3pBIX2S4xCjE0aSrA0\"",
		"mtime": "2026-08-15T10:59:24.211Z",
		"size": 162749,
		"path": "../public/assets/fish/common_shiner.png"
	},
	"/assets/fish/copper_corydoras.png": {
		"type": "image/png",
		"etag": "\"3bf37-rmiyYz3J7MxaqrtTc9hrJK5pAWo\"",
		"mtime": "2026-08-15T10:59:24.260Z",
		"size": 245559,
		"path": "../public/assets/fish/copper_corydoras.png"
	},
	"/assets/fish/coral_guardian.png": {
		"type": "image/png",
		"etag": "\"4686c-nblfQsG+TbuQTDXhVb/pzd9oUUY\"",
		"mtime": "2026-08-04T10:08:10.000Z",
		"size": 288876,
		"path": "../public/assets/fish/coral_guardian.png"
	},
	"/assets/fish/creek_chub.png": {
		"type": "image/png",
		"etag": "\"20853-ovxnWTWICuSBUKg+ZzRXmJQIyfo\"",
		"mtime": "2026-08-08T02:33:20.000Z",
		"size": 133203,
		"path": "../public/assets/fish/creek_chub.png"
	},
	"/assets/fish/crystal_sturgeon.png": {
		"type": "image/png",
		"etag": "\"31ba6-mhraM0UrJTGILaUJFYgPekU+uVU\"",
		"mtime": "2026-08-15T10:59:24.220Z",
		"size": 203686,
		"path": "../public/assets/fish/crystal_sturgeon.png"
	},
	"/assets/fish/crawdad.png": {
		"type": "image/png",
		"etag": "\"53e55-ma9CadmTQb7o1dauWtXQsLgUWu4\"",
		"mtime": "2026-08-04T10:08:24.000Z",
		"size": 343637,
		"path": "../public/assets/fish/crawdad.png"
	},
	"/assets/fish/crystal_tetra.png": {
		"type": "image/png",
		"etag": "\"2f743-rxQUPSsngOnb5v036Lnn3h2axFo\"",
		"mtime": "2026-08-04T10:08:36.000Z",
		"size": 194371,
		"path": "../public/assets/fish/crystal_tetra.png"
	},
	"/assets/fish/cursed_mackerel.png": {
		"type": "image/png",
		"etag": "\"3cdb9-KaWZm2I8XWQ5c75oycAl5SPJFnM\"",
		"mtime": "2026-08-04T10:08:54.000Z",
		"size": 249273,
		"path": "../public/assets/fish/cursed_mackerel.png"
	},
	"/assets/fish/davy_jones_locket_fish.png": {
		"type": "image/png",
		"etag": "\"334da-iHP4hW4XOhROwQDyE1W8/UVFNOg\"",
		"mtime": "2026-08-04T08:15:44.000Z",
		"size": 210138,
		"path": "../public/assets/fish/davy_jones_locket_fish.png"
	},
	"/assets/fish/deep_sea_serpent.png": {
		"type": "image/png",
		"etag": "\"4004e-ovZnVxlNOEdzkg7XBZN4c5OVS4o\"",
		"mtime": "2026-08-04T10:09:20.000Z",
		"size": 262222,
		"path": "../public/assets/fish/deep_sea_serpent.png"
	},
	"/assets/fish/diamond_scaled_wyrm.png": {
		"type": "image/png",
		"etag": "\"2e36f-FAxd8Yg9ZyHyF54chj31sk/76mQ\"",
		"mtime": "2026-08-04T08:15:54.000Z",
		"size": 189295,
		"path": "../public/assets/fish/diamond_scaled_wyrm.png"
	},
	"/assets/fish/driftwood_catfish.png": {
		"type": "image/png",
		"etag": "\"27898-Q0Vk8FJCHdZyvnJvxBhzin9zBrI\"",
		"mtime": "2026-08-08T02:33:20.000Z",
		"size": 161944,
		"path": "../public/assets/fish/driftwood_catfish.png"
	},
	"/assets/fish/elephant_nose_fish.png": {
		"type": "image/png",
		"etag": "\"304f7-Z6yQDlrJucVGsRJWtBP6N+8Ez6g\"",
		"mtime": "2026-08-15T10:59:26.404Z",
		"size": 197879,
		"path": "../public/assets/fish/elephant_nose_fish.png"
	},
	"/assets/fish/discus_fish.png": {
		"type": "image/png",
		"etag": "\"5922f-bufFJEpsv5A4LbXHUJ6DMcnHE08\"",
		"mtime": "2026-08-15T10:59:26.416Z",
		"size": 365103,
		"path": "../public/assets/fish/discus_fish.png"
	},
	"/assets/fish/ember_eel.png": {
		"type": "image/png",
		"etag": "\"3d031-SysJaatEmPPpgi8lfioy/2hDaOY\"",
		"mtime": "2026-08-04T10:09:36.000Z",
		"size": 249905,
		"path": "../public/assets/fish/ember_eel.png"
	},
	"/assets/fish/emerald_arowana.png": {
		"type": "image/png",
		"etag": "\"2e2cf-zsYbgozDcfFAvlRVouq9yFHuCqM\"",
		"mtime": "2026-08-08T02:33:20.000Z",
		"size": 189135,
		"path": "../public/assets/fish/emerald_arowana.png"
	},
	"/assets/fish/electric_eel.png": {
		"type": "image/png",
		"etag": "\"2db27-hF1ovjlkzTd/ifnqabtCIJjgRLE\"",
		"mtime": "2026-08-08T02:33:22.000Z",
		"size": 187175,
		"path": "../public/assets/fish/electric_eel.png"
	},
	"/assets/fish/ethereal_manta.png": {
		"type": "image/png",
		"etag": "\"2013d-UdbaaT7xrvMdqt7kAOTrFPFuOlk\"",
		"mtime": "2026-08-15T10:59:26.332Z",
		"size": 131389,
		"path": "../public/assets/fish/ethereal_manta.png"
	},
	"/assets/fish/flying_fish.png": {
		"type": "image/png",
		"etag": "\"270e4-kH4bdC3/jWcCrFI4SyJfubWKrAQ\"",
		"mtime": "2026-08-08T02:33:22.000Z",
		"size": 159972,
		"path": "../public/assets/fish/flying_fish.png"
	},
	"/assets/fish/fossil_dunkleosteus.png": {
		"type": "image/png",
		"etag": "\"37858-FVYs49KeiJd77QO8K3CVlrZ53VU\"",
		"mtime": "2026-08-08T02:33:22.000Z",
		"size": 227416,
		"path": "../public/assets/fish/fossil_dunkleosteus.png"
	},
	"/assets/fish/frist_wyrm_fish.png": {
		"type": "image/png",
		"etag": "\"3a2ff-1i44gd06Nb0gXzhnvxkHpmNITyk\"",
		"mtime": "2026-08-15T10:59:26.347Z",
		"size": 238335,
		"path": "../public/assets/fish/frist_wyrm_fish.png"
	},
	"/assets/fish/frostbite_cod.png": {
		"type": "image/png",
		"etag": "\"2a0bf-/mE9mWxXZKrBX6nSY1AagkVoJiM\"",
		"mtime": "2026-08-08T02:34:24.000Z",
		"size": 172223,
		"path": "../public/assets/fish/frostbite_cod.png"
	},
	"/assets/fish/frostfin_salmon.png": {
		"type": "image/png",
		"etag": "\"30305-GsIqyo7/UzwV7hc0g9jv+3bKyvg\"",
		"mtime": "2026-08-04T10:09:52.000Z",
		"size": 197381,
		"path": "../public/assets/fish/frostfin_salmon.png"
	},
	"/assets/fish/frost_orca_pup.png": {
		"type": "image/png",
		"etag": "\"3cd0c-o5/nGaWszqlqOBQaTXPnctBvlbo\"",
		"mtime": "2026-08-08T02:33:22.000Z",
		"size": 249100,
		"path": "../public/assets/fish/frost_orca_pup.png"
	},
	"/assets/fish/galaxy_whale_shark.png": {
		"type": "image/png",
		"etag": "\"33512-wmMV1LN451rXMeJKnRi+Mgyk1t0\"",
		"mtime": "2026-08-08T02:34:24.000Z",
		"size": 210194,
		"path": "../public/assets/fish/galaxy_whale_shark.png"
	},
	"/assets/fish/glacier_wyrmling.png": {
		"type": "image/png",
		"etag": "\"2cd3e-iQQ6wBfRoROgtptJvqgWUMv7KYs\"",
		"mtime": "2026-08-04T10:10:58.000Z",
		"size": 183614,
		"path": "../public/assets/fish/glacier_wyrmling.png"
	},
	"/assets/fish/geode_turtle.png": {
		"type": "image/png",
		"etag": "\"34587-VKxGvRCshlWBPUYbvoH9jktfKA4\"",
		"mtime": "2026-08-04T10:10:08.000Z",
		"size": 214407,
		"path": "../public/assets/fish/geode_turtle.png"
	},
	"/assets/fish/ghost_shrimp.png": {
		"type": "image/png",
		"etag": "\"24b75-5fjzOAQgEfIQb6PWdSPzvpJfkHQ\"",
		"mtime": "2026-08-04T10:10:26.000Z",
		"size": 150389,
		"path": "../public/assets/fish/ghost_shrimp.png"
	},
	"/assets/fish/golden_arowana.png": {
		"type": "image/png",
		"etag": "\"23515-jEMs3swxzq+nsv3PnQ+r+fIoZfI\"",
		"mtime": "2026-08-15T10:59:26.324Z",
		"size": 144661,
		"path": "../public/assets/fish/golden_arowana.png"
	},
	"/assets/fish/giant_squid_hatchling.png": {
		"type": "image/png",
		"etag": "\"3a0ae-IhDvwAoGziNsjRrwaJpqlFobmdw\"",
		"mtime": "2026-08-04T10:10:42.000Z",
		"size": 237742,
		"path": "../public/assets/fish/giant_squid_hatchling.png"
	},
	"/assets/fish/glass_catfish.png": {
		"type": "image/png",
		"etag": "\"2c407-XsMM+FeOsVMZ9c6Kc5I4xH54Z7w\"",
		"mtime": "2026-08-08T02:34:24.000Z",
		"size": 181255,
		"path": "../public/assets/fish/glass_catfish.png"
	},
	"/assets/fish/golden_pond_carp.png": {
		"type": "image/png",
		"etag": "\"29f94-cJreKvjPdbyWhaGc3Nv3Qj1hFBE\"",
		"mtime": "2026-08-04T08:16:04.000Z",
		"size": 171924,
		"path": "../public/assets/fish/golden_pond_carp.png"
	},
	"/assets/fish/grim_reaper_angler.png": {
		"type": "image/png",
		"etag": "\"371c7-CbUI7dzS+G77BBOJKd4H0ectvgI\"",
		"mtime": "2026-08-15T10:59:27.491Z",
		"size": 225735,
		"path": "../public/assets/fish/grim_reaper_angler.png"
	},
	"/assets/fish/guardian_sphinx_fish.png": {
		"type": "image/png",
		"etag": "\"2ef98-LU0OR4FqvnUh2nF9kA64/WF6tis\"",
		"mtime": "2026-08-04T08:23:08.000Z",
		"size": 192408,
		"path": "../public/assets/fish/guardian_sphinx_fish.png"
	},
	"/assets/fish/herring.png": {
		"type": "image/png",
		"etag": "\"34815-WJIuQ5HeueLGFhMYYotJlNb6fjY\"",
		"mtime": "2026-08-04T10:11:30.000Z",
		"size": 215061,
		"path": "../public/assets/fish/herring.png"
	},
	"/assets/fish/ice_perch.png": {
		"type": "image/png",
		"etag": "\"33b4d-FhGIFdoLughb2xlZ4BTr45eGDOY\"",
		"mtime": "2026-08-04T10:11:46.000Z",
		"size": 211789,
		"path": "../public/assets/fish/ice_perch.png"
	},
	"/assets/fish/jurassic_megaladon_pup.png": {
		"type": "image/png",
		"etag": "\"41af0-su16kLFVnD1bukXMzPmPqEobKWQ\"",
		"mtime": "2026-08-15T10:59:27.510Z",
		"size": 269040,
		"path": "../public/assets/fish/jurassic_megaladon_pup.png"
	},
	"/assets/fish/krakens_eye_jelly.png": {
		"type": "image/png",
		"etag": "\"38649-VZLLZarMtkmDHr2QLyJ1nNPb8R8\"",
		"mtime": "2026-08-04T08:23:30.000Z",
		"size": 230985,
		"path": "../public/assets/fish/krakens_eye_jelly.png"
	},
	"/assets/fish/lake_guardian_turtle.png": {
		"type": "image/png",
		"etag": "\"3335b-cNcuz7qJyYDFCGIrJj4LYO2/D9U\"",
		"mtime": "2026-08-04T10:04:46.000Z",
		"size": 209755,
		"path": "../public/assets/fish/lake_guardian_turtle.png"
	},
	"/assets/fish/kraken_tentacle_fish.png": {
		"type": "image/png",
		"etag": "\"48a4b-NsNF+E6eTC5p5ai9mXKLdqwKZSw\"",
		"mtime": "2026-08-08T02:34:24.000Z",
		"size": 297547,
		"path": "../public/assets/fish/kraken_tentacle_fish.png"
	},
	"/assets/fish/lake_sturgeon.png": {
		"type": "image/png",
		"etag": "\"2d955-ywa7NulYv5uYa+JLiHebBh2OjIA\"",
		"mtime": "2026-08-04T10:11:58.000Z",
		"size": 186709,
		"path": "../public/assets/fish/lake_sturgeon.png"
	},
	"/assets/fish/lantern_fish.png": {
		"type": "image/png",
		"etag": "\"1d8db-MKv4oQqK7s43MMNhNhouEb0ZJzE\"",
		"mtime": "2026-08-08T02:34:24.000Z",
		"size": 121051,
		"path": "../public/assets/fish/lantern_fish.png"
	},
	"/assets/fish/largemouth_bass.png": {
		"type": "image/png",
		"etag": "\"2db4a-Zp7E1NgVKVVEKrnAiKNFtQ9YSAI\"",
		"mtime": "2026-08-04T10:12:12.000Z",
		"size": 187210,
		"path": "../public/assets/fish/largemouth_bass.png"
	},
	"/assets/fish/leaf_fish.png": {
		"type": "image/png",
		"etag": "\"311a1-V/Y7bavmfTnMnIqjyKHQTpbXAKM\"",
		"mtime": "2026-08-15T10:59:27.465Z",
		"size": 201121,
		"path": "../public/assets/fish/leaf_fish.png"
	},
	"/assets/fish/lucid_dream_serpent.png": {
		"type": "image/png",
		"etag": "\"3222b-KXPjHwUjU4knglbehll7OrA+mmE\"",
		"mtime": "2026-08-04T08:16:28.000Z",
		"size": 205355,
		"path": "../public/assets/fish/lucid_dream_serpent.png"
	},
	"/assets/fish/mackerel.png": {
		"type": "image/png",
		"etag": "\"24c9c-HJIsrd7O5HpKpbMKKYY6kdVSZOA\"",
		"mtime": "2026-08-04T10:12:28.000Z",
		"size": 150684,
		"path": "../public/assets/fish/mackerel.png"
	},
	"/assets/fish/magma_minnow.png": {
		"type": "image/png",
		"etag": "\"34ffe-SDpnWORvPc26xywMh8uyjI8oKYA\"",
		"mtime": "2026-08-04T10:12:40.000Z",
		"size": 217086,
		"path": "../public/assets/fish/magma_minnow.png"
	},
	"/assets/fish/molten_core_serpent.png": {
		"type": "image/png",
		"etag": "\"345c4-BB69VGn6O9t2OLLtvyeVdA/d1DM\"",
		"mtime": "2026-08-04T08:16:36.000Z",
		"size": 214468,
		"path": "../public/assets/fish/molten_core_serpent.png"
	},
	"/assets/fish/marsh_frogfish.png": {
		"type": "image/png",
		"etag": "\"364dc-22hOz9WJjyJlbC292VPvIZq79oQ\"",
		"mtime": "2026-08-04T10:13:04.000Z",
		"size": 222428,
		"path": "../public/assets/fish/marsh_frogfish.png"
	},
	"/assets/fish/maelstrom_serpent_hatchling.png": {
		"type": "image/png",
		"etag": "\"f2e2a-oyx0TOWqREH46VHZwSxSRjVG+Ks\"",
		"mtime": "2026-08-15T10:58:22.762Z",
		"size": 994858,
		"path": "../public/assets/fish/maelstrom_serpent_hatchling.png"
	},
	"/assets/fish/moonlit_perch.png": {
		"type": "image/png",
		"etag": "\"3581c-6C9ONv3l8WFCsE2jFDvm2zb9iPA\"",
		"mtime": "2026-08-04T10:13:22.000Z",
		"size": 219164,
		"path": "../public/assets/fish/moonlit_perch.png"
	},
	"/assets/fish/magma_angler.png": {
		"type": "image/png",
		"etag": "\"8af46-yvOLZeEFMPP/kTxApDP9N7lzK1g\"",
		"mtime": "2026-08-08T02:32:22.000Z",
		"size": 569158,
		"path": "../public/assets/fish/magma_angler.png"
	},
	"/assets/fish/magma_ray.png": {
		"type": "image/png",
		"etag": "\"97f02-ayZPKe2CDx3mF+V51B8LJH1isWw\"",
		"mtime": "2026-08-15T10:58:22.682Z",
		"size": 622338,
		"path": "../public/assets/fish/magma_ray.png"
	},
	"/assets/fish/mudskipper.png": {
		"type": "image/png",
		"etag": "\"2ea5b-spjm4h0JOq+ayaGwPDMusi8G2m4\"",
		"mtime": "2026-08-04T10:13:38.000Z",
		"size": 191067,
		"path": "../public/assets/fish/mudskipper.png"
	},
	"/assets/fish/mud_loach.png": {
		"type": "image/png",
		"etag": "\"75dce-9EgiPX+ByE0trhVBlhUFwgZ6+7s\"",
		"mtime": "2026-08-15T10:58:22.923Z",
		"size": 482766,
		"path": "../public/assets/fish/mud_loach.png"
	},
	"/assets/fish/mandarin_fish.png": {
		"type": "image/png",
		"etag": "\"ef8a3-J4IYIwhUhF+X8LEwhnQRIXTDw3I\"",
		"mtime": "2026-08-15T10:58:22.899Z",
		"size": 981155,
		"path": "../public/assets/fish/mandarin_fish.png"
	},
	"/assets/fish/nebula_grouper.png": {
		"type": "image/png",
		"etag": "\"3b529-42u+nW3L2KFLDISFF5dhdNCDkws\"",
		"mtime": "2026-08-15T10:58:23.984Z",
		"size": 242985,
		"path": "../public/assets/fish/nebula_grouper.png"
	},
	"/assets/fish/moonlight_tetra.png": {
		"type": "image/png",
		"etag": "\"d749e-zjxjtC50iSR1p1n9dnmBXNW+8r8\"",
		"mtime": "2026-08-08T02:32:22.000Z",
		"size": 881822,
		"path": "../public/assets/fish/moonlight_tetra.png"
	},
	"/assets/fish/null_current_wyrm.png": {
		"type": "image/png",
		"etag": "\"274b6-UdA97dypgwXBU2nKhpL65WOJCIw\"",
		"mtime": "2026-08-04T08:16:44.000Z",
		"size": 160950,
		"path": "../public/assets/fish/null_current_wyrm.png"
	},
	"/assets/fish/neon_tetra.png": {
		"type": "image/png",
		"etag": "\"21a30-0YoY8WkKCQ51K+qc22m+lBEOOD8\"",
		"mtime": "2026-08-15T10:58:23.961Z",
		"size": 137776,
		"path": "../public/assets/fish/neon_tetra.png"
	},
	"/assets/fish/lionfish.png": {
		"type": "image/png",
		"etag": "\"109346-qNo50+C2e3DEiRmG8qR31tCrjYI\"",
		"mtime": "2026-08-08T02:32:22.000Z",
		"size": 1086278,
		"path": "../public/assets/fish/lionfish.png"
	},
	"/assets/fish/obsidian_placoderm.png": {
		"type": "image/png",
		"etag": "\"3d461-22AgQR8dkwG2L5PAqoAzmdjvIwA\"",
		"mtime": "2026-08-15T10:58:24.425Z",
		"size": 250977,
		"path": "../public/assets/fish/obsidian_placoderm.png"
	},
	"/assets/fish/mossy_stone_loach.png": {
		"type": "image/png",
		"etag": "\"8e0cf-bv2AMgujCHzZvr08CehnM6NLtBs\"",
		"mtime": "2026-08-15T10:58:22.936Z",
		"size": 581839,
		"path": "../public/assets/fish/mossy_stone_loach.png"
	},
	"/assets/fish/moss_goby.png": {
		"type": "image/png",
		"etag": "\"a59dd-CuQENR9R9L5H3RO89iAQT+imNFo\"",
		"mtime": "2026-08-08T02:32:22.000Z",
		"size": 678365,
		"path": "../public/assets/fish/moss_goby.png"
	},
	"/assets/fish/obsidian_ray.png": {
		"type": "image/png",
		"etag": "\"1c6ac-kBGglAdV1uQJFfhX4TACehRM+SI\"",
		"mtime": "2026-08-04T10:13:58.000Z",
		"size": 116396,
		"path": "../public/assets/fish/obsidian_ray.png"
	},
	"/assets/fish/origami_koi.png": {
		"type": "image/png",
		"etag": "\"2bcd9-ELDZH1DUYWRynM5S+hmxlidT8fk\"",
		"mtime": "2026-08-15T10:58:23.971Z",
		"size": 179417,
		"path": "../public/assets/fish/origami_koi.png"
	},
	"/assets/fish/parrotfish.png": {
		"type": "image/png",
		"etag": "\"38d0b-7RhAnOf9VsDZrpN82Z1NXh5zf58\"",
		"mtime": "2026-08-04T10:14:16.000Z",
		"size": 232715,
		"path": "../public/assets/fish/parrotfish.png"
	},
	"/assets/fish/phantom_captains_eel.png": {
		"type": "image/png",
		"etag": "\"1f152-KHZtP5yD02/foV34TrnS/afB2ME\"",
		"mtime": "2026-08-04T08:16:50.000Z",
		"size": 127314,
		"path": "../public/assets/fish/phantom_captains_eel.png"
	},
	"/assets/fish/necro_lamprey.png": {
		"type": "image/png",
		"etag": "\"f230d-Nw9lor1ltwrI2WBQZji6tex2pro\"",
		"mtime": "2026-08-08T02:32:22.000Z",
		"size": 992013,
		"path": "../public/assets/fish/necro_lamprey.png"
	},
	"/assets/fish/phanton_ribbon_eel.png": {
		"type": "image/png",
		"etag": "\"31a66-hlJKd9X7dzZ1+v95Dec6gu44FZA\"",
		"mtime": "2026-08-15T10:58:23.833Z",
		"size": 203366,
		"path": "../public/assets/fish/phanton_ribbon_eel.png"
	},
	"/assets/fish/pharaohs_golden_carp.png": {
		"type": "image/png",
		"etag": "\"35cd1-3CfQEmH/l+xrAh/A9vEWk/fOeTw\"",
		"mtime": "2026-08-04T08:24:18.000Z",
		"size": 220369,
		"path": "../public/assets/fish/pharaohs_golden_carp.png"
	},
	"/assets/fish/phoenix_dragonfish.png": {
		"type": "image/png",
		"etag": "\"2e9a4-l9oCjDgQ029k4odr0lDInL4d/bg\"",
		"mtime": "2026-08-08T02:32:24.000Z",
		"size": 190884,
		"path": "../public/assets/fish/phoenix_dragonfish.png"
	},
	"/assets/fish/phoenix_koi.png": {
		"type": "image/png",
		"etag": "\"2dd43-GP3sbjFS36mvD6yvp6Q9qkXdomY\"",
		"mtime": "2026-08-04T08:17:40.000Z",
		"size": 187715,
		"path": "../public/assets/fish/phoenix_koi.png"
	},
	"/assets/fish/pond_koi.png": {
		"type": "image/png",
		"etag": "\"32425-kQsMmPvGF5SaYDCf//F/0zwXpB0\"",
		"mtime": "2026-08-04T10:14:32.000Z",
		"size": 205861,
		"path": "../public/assets/fish/pond_koi.png"
	},
	"/assets/fish/pond_minnow.png": {
		"type": "image/png",
		"etag": "\"19282-N/bcZbNmR9N/EFyiFD3jSFCzavw\"",
		"mtime": "2026-08-04T10:14:54.000Z",
		"size": 103042,
		"path": "../public/assets/fish/pond_minnow.png"
	},
	"/assets/fish/pond_smelt.png": {
		"type": "image/png",
		"etag": "\"1f179-2XfRKgWpjuGyAfNb/zWiMHI4RLM\"",
		"mtime": "2026-08-15T10:58:25.293Z",
		"size": 127353,
		"path": "../public/assets/fish/pond_smelt.png"
	},
	"/assets/fish/prism_angel.png": {
		"type": "image/png",
		"etag": "\"3b66a-7mBPdUU0XrJed9UVs2RS8FSrpZ8\"",
		"mtime": "2026-08-08T02:32:24.000Z",
		"size": 243306,
		"path": "../public/assets/fish/prism_angel.png"
	},
	"/assets/fish/poseidons_herald.png": {
		"type": "image/png",
		"etag": "\"3651d-TmaFvHcmO4kmJ1N6d6VydpfgwV0\"",
		"mtime": "2026-08-04T08:18:04.000Z",
		"size": 222493,
		"path": "../public/assets/fish/poseidons_herald.png"
	},
	"/assets/fish/puddle_guppy.png": {
		"type": "image/png",
		"etag": "\"28dba-WQiDwxyovyJp9iC9odPZ03a0CQE\"",
		"mtime": "2026-08-08T02:32:24.000Z",
		"size": 167354,
		"path": "../public/assets/fish/puddle_guppy.png"
	},
	"/assets/fish/prism_serpent.png": {
		"type": "image/png",
		"etag": "\"4bdc1-GHbafL8VotQXDjbD+Ux4T73XFxU\"",
		"mtime": "2026-08-04T08:19:30.000Z",
		"size": 310721,
		"path": "../public/assets/fish/prism_serpent.png"
	},
	"/assets/fish/rainbow_reef_dragon.png": {
		"type": "image/png",
		"etag": "\"3eda2-RlSwlQRKUx3n5TqfwjwOGTG0Q58\"",
		"mtime": "2026-08-04T08:20:14.000Z",
		"size": 257442,
		"path": "../public/assets/fish/rainbow_reef_dragon.png"
	},
	"/assets/fish/rainbow_sky_serpent.png": {
		"type": "image/png",
		"etag": "\"2981c-faYuv9WoBExl+L/sre8G66KjDvo\"",
		"mtime": "2026-08-04T08:20:36.000Z",
		"size": 170012,
		"path": "../public/assets/fish/rainbow_sky_serpent.png"
	},
	"/assets/fish/rainbow_trout.png": {
		"type": "image/png",
		"etag": "\"2585b-sORJcpP61bTSLW6RJlvZYwQtrQM\"",
		"mtime": "2026-08-04T10:15:12.000Z",
		"size": 153691,
		"path": "../public/assets/fish/rainbow_trout.png"
	},
	"/assets/fish/reef_shark_pup.png": {
		"type": "image/png",
		"etag": "\"22240-evcceGhVaZSUXq6Ewe0YHJwzvVE\"",
		"mtime": "2026-08-04T10:15:28.000Z",
		"size": 139840,
		"path": "../public/assets/fish/reef_shark_pup.png"
	},
	"/assets/fish/reverie_koi.png": {
		"type": "image/png",
		"etag": "\"3c627-nuAu5VZgZ29H6D+kSfHH4cRC8xE\"",
		"mtime": "2026-08-04T08:20:52.000Z",
		"size": 247335,
		"path": "../public/assets/fish/reverie_koi.png"
	},
	"/assets/fish/runic_coelacanth.png": {
		"type": "image/png",
		"etag": "\"3be00-upFi/O4th8eqstmM5OnjGGo2DLo\"",
		"mtime": "2026-08-08T02:32:24.000Z",
		"size": 245248,
		"path": "../public/assets/fish/runic_coelacanth.png"
	},
	"/assets/fish/sand_darter.png": {
		"type": "image/png",
		"etag": "\"18f3b-5L6kALyOAFew+lBHCTfWf1mI+4c\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 102203,
		"path": "../public/assets/fish/sand_darter.png"
	},
	"/assets/fish/seraphim_koi.png": {
		"type": "image/png",
		"etag": "\"20c6c-ocjnZaJKQ4lISybI0DsTv5xH3Po\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 134252,
		"path": "../public/assets/fish/seraphim_koi.png"
	},
	"/assets/fish/shadow_stingray.png": {
		"type": "image/png",
		"etag": "\"1ff77-ldsmyc/+IEMxCrqFwvtakW5GhM8\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 130935,
		"path": "../public/assets/fish/shadow_stingray.png"
	},
	"/assets/fish/rock_bass.png": {
		"type": "image/png",
		"etag": "\"3bb89-IwRw03NLzGIvUldxLvTwVD42ahg\"",
		"mtime": "2026-08-08T02:32:24.000Z",
		"size": 244617,
		"path": "../public/assets/fish/rock_bass.png"
	},
	"/assets/fish/shipwreck_kraken_spawn.png": {
		"type": "image/png",
		"etag": "\"2ee12-HuZxk+/J0I8m2+Z6h20TzLgEO54\"",
		"mtime": "2026-08-04T10:16:28.000Z",
		"size": 192018,
		"path": "../public/assets/fish/shipwreck_kraken_spawn.png"
	},
	"/assets/fish/river_spirit_eel.png": {
		"type": "image/png",
		"etag": "\"364c8-nE7AHeadFYw/5ILzTmtY9BxL3QY\"",
		"mtime": "2026-08-04T10:15:52.000Z",
		"size": 222408,
		"path": "../public/assets/fish/river_spirit_eel.png"
	},
	"/assets/fish/river_trout.png": {
		"type": "image/png",
		"etag": "\"25ebc-IXN7aUVZ1X+4b07U/5Ug5elOXJ4\"",
		"mtime": "2026-08-04T10:16:10.000Z",
		"size": 155324,
		"path": "../public/assets/fish/river_trout.png"
	},
	"/assets/fish/silver_beam.png": {
		"type": "image/png",
		"etag": "\"20930-6790iulYSIF16nicAbKrOWEMa04\"",
		"mtime": "2026-08-15T10:58:25.657Z",
		"size": 133424,
		"path": "../public/assets/fish/silver_beam.png"
	},
	"/assets/fish/silent_deep_horror.png": {
		"type": "image/png",
		"etag": "\"2bfcd-2kQmBnvpRbuLe45/B9Ik4M44x3Q\"",
		"mtime": "2026-08-04T08:21:06.000Z",
		"size": 180173,
		"path": "../public/assets/fish/silent_deep_horror.png"
	},
	"/assets/fish/silver_pike.png": {
		"type": "image/png",
		"etag": "\"1e571-XiRXtanZRcFcmbyvtsOZAOJMTZk\"",
		"mtime": "2026-08-04T10:16:50.000Z",
		"size": 124273,
		"path": "../public/assets/fish/silver_pike.png"
	},
	"/assets/fish/solar_flare_ray.png": {
		"type": "image/png",
		"etag": "\"2a734-QfHYqZp2kS5mHAMI6/QNWJEIw2c\"",
		"mtime": "2026-08-15T10:58:25.584Z",
		"size": 173876,
		"path": "../public/assets/fish/solar_flare_ray.png"
	},
	"/assets/fish/solar_sailfish.png": {
		"type": "image/png",
		"etag": "\"2a638-8qnAErU3j+gYg9HIECAyDxAuSjM\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 173624,
		"path": "../public/assets/fish/solar_sailfish.png"
	},
	"/assets/fish/spotted_gar.png": {
		"type": "image/png",
		"etag": "\"2557c-cyaWXk5+yXnt6BtHCoVPLrJHUig\"",
		"mtime": "2026-08-15T10:58:25.605Z",
		"size": 152956,
		"path": "../public/assets/fish/spotted_gar.png"
	},
	"/assets/fish/spectral_seahorse.png": {
		"type": "image/png",
		"etag": "\"329b1-tNFCmh5Cy/GIh2erCS59PJIq6yo\"",
		"mtime": "2026-08-15T10:58:25.543Z",
		"size": 207281,
		"path": "../public/assets/fish/spectral_seahorse.png"
	},
	"/assets/fish/soul_stealer_carp.png": {
		"type": "image/png",
		"etag": "\"25129-oh0luKsPr2MXcreb0PHn6YOd3N0\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 151849,
		"path": "../public/assets/fish/soul_stealer_carp.png"
	},
	"/assets/fish/stargazer_fish.png": {
		"type": "image/png",
		"etag": "\"2596e-5ILzBZ54LswS4OaAngccVSr1KBE\"",
		"mtime": "2026-08-15T10:58:26.719Z",
		"size": 153966,
		"path": "../public/assets/fish/stargazer_fish.png"
	},
	"/assets/fish/starlight_flounder.png": {
		"type": "image/png",
		"etag": "\"2ec0a-92Rr7BvNy4cpVAs/TwC/qjkmOWw\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 191498,
		"path": "../public/assets/fish/starlight_flounder.png"
	},
	"/assets/fish/sunfish_fry.png": {
		"type": "image/png",
		"etag": "\"18ea2-hyHp4YiYUfrfmnpm8o7eVLSHJKg\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 102050,
		"path": "../public/assets/fish/sunfish_fry.png"
	},
	"/assets/fish/supernova_shrimp.png": {
		"type": "image/png",
		"etag": "\"3dbbb-3/bzjAzCSzKCRfL0FWWb9kfawK0\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 252859,
		"path": "../public/assets/fish/supernova_shrimp.png"
	},
	"/assets/fish/sunstone_leviathan.png": {
		"type": "image/png",
		"etag": "\"28916-o2Ii82aVBB9PjAkh/3tDcgnfCyA\"",
		"mtime": "2026-08-04T08:21:44.000Z",
		"size": 166166,
		"path": "../public/assets/fish/sunstone_leviathan.png"
	},
	"/assets/fish/swordfish.png": {
		"type": "image/png",
		"etag": "\"2025f-TOYGzytkGfUZG2oRq52i0lPXWbw\"",
		"mtime": "2026-08-04T10:17:24.000Z",
		"size": 131679,
		"path": "../public/assets/fish/swordfish.png"
	},
	"/assets/fish/theradfin_ranbowfish.png": {
		"type": "image/png",
		"etag": "\"4cd2a-YbtobHyAJfLsa+/IADye5CgQUug\"",
		"mtime": "2026-08-15T10:58:26.733Z",
		"size": 314666,
		"path": "../public/assets/fish/theradfin_ranbowfish.png"
	},
	"/assets/fish/thunderbird_koi.png": {
		"type": "image/png",
		"etag": "\"36ae2-yEWv4Ck4A7EZaZez76yUVKSB5Y0\"",
		"mtime": "2026-08-04T08:22:04.000Z",
		"size": 223970,
		"path": "../public/assets/fish/thunderbird_koi.png"
	},
	"/assets/fish/stormcaller_eel.png": {
		"type": "image/png",
		"etag": "\"3bc78-oOoBSSYl4cptQZkN7fPseF5E4HM\"",
		"mtime": "2026-08-04T08:21:20.000Z",
		"size": 244856,
		"path": "../public/assets/fish/stormcaller_eel.png"
	},
	"/assets/fish/swamp_snapper_turtle.png": {
		"type": "image/png",
		"etag": "\"3c564-wvZvHVyAC5VoCePRIugyYMpTMRA\"",
		"mtime": "2026-08-04T10:17:06.000Z",
		"size": 247140,
		"path": "../public/assets/fish/swamp_snapper_turtle.png"
	},
	"/assets/fish/thunder_eel.png": {
		"type": "image/png",
		"etag": "\"2fbf8-7wgNXe6CyEBfP5ytjAGgl3NHMf4\"",
		"mtime": "2026-08-15T10:58:26.760Z",
		"size": 195576,
		"path": "../public/assets/fish/thunder_eel.png"
	},
	"/assets/fish/tiger_barb.png": {
		"type": "image/png",
		"etag": "\"265d8-R3wlnpFITCyZvAYuS1K/AADQU5o\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 157144,
		"path": "../public/assets/fish/tiger_barb.png"
	},
	"/assets/fish/time_rift_squid.png": {
		"type": "image/png",
		"etag": "\"39b77-YqlMP0GDXYx2ebugpf0j6bsA8rk\"",
		"mtime": "2026-08-15T10:58:26.780Z",
		"size": 236407,
		"path": "../public/assets/fish/time_rift_squid.png"
	},
	"/assets/fish/time_weaver_eel.png": {
		"type": "image/png",
		"etag": "\"3b3bb-+gu11hMHCYAl87Wm2JcsITm0cdQ\"",
		"mtime": "2026-08-08T02:32:26.000Z",
		"size": 242619,
		"path": "../public/assets/fish/time_weaver_eel.png"
	},
	"/assets/fish/toxic_puff.png": {
		"type": "image/png",
		"etag": "\"35b15-WVw++Bj/7IxTZ1ZX8ZGCieyNcCo\"",
		"mtime": "2026-08-08T02:32:28.000Z",
		"size": 219925,
		"path": "../public/assets/fish/toxic_puff.png"
	},
	"/assets/fish/voidscale_ripper.png": {
		"type": "image/png",
		"etag": "\"29591-m58NtFCT4ZHiKKjSPI+EXpcYdgE\"",
		"mtime": "2026-08-04T08:22:18.000Z",
		"size": 169361,
		"path": "../public/assets/fish/voidscale_ripper.png"
	},
	"/assets/fish/void_walker_crab.png": {
		"type": "image/png",
		"etag": "\"50c73-456xOGRm8EH3XBR6+ViQ2Dv3xV4\"",
		"mtime": "2026-08-15T10:59:17.495Z",
		"size": 330867,
		"path": "../public/assets/fish/void_walker_crab.png"
	},
	"/assets/fish/venomous_liontoad.png": {
		"type": "image/png",
		"etag": "\"413fd-P/14MkO5YHSuN1D8OBojCNbc4ro\"",
		"mtime": "2026-08-15T10:58:26.802Z",
		"size": 267261,
		"path": "../public/assets/fish/venomous_liontoad.png"
	},
	"/assets/fish/willowisp_fish.png": {
		"type": "image/png",
		"etag": "\"2bfdc-g7mC0uJiVbA3ATWPFxBdRr0nJGI\"",
		"mtime": "2026-08-04T10:17:40.000Z",
		"size": 180188,
		"path": "../public/assets/fish/willowisp_fish.png"
	},
	"/assets/fish/yellow_perch.png": {
		"type": "image/png",
		"etag": "\"29f47-CGoQlyFe3BwWm9YD1dBMQHjz7LU\"",
		"mtime": "2026-08-08T02:32:28.000Z",
		"size": 171847,
		"path": "../public/assets/fish/yellow_perch.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_cnXbTC = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_cnXbTC
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
