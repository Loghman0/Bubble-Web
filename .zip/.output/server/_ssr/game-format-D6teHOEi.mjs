//#region node_modules/.nitro/vite/services/ssr/assets/game-format-D6teHOEi.js
/**
* Small formatting helpers shared by the encyclopedia detail pages
* (fish/baits/pets/eggs/enchants) for turning raw bot data into readable text.
*/
/** "village_pond" -> "Village Pond" */
var titleCase = (id) => id.split("_").map((w) => w ? w[0].toUpperCase() + w.slice(1) : w).join(" ");
/** "any" -> "Any" | "fog" -> "Fog" | ["morning","day"] -> "Morning, Day" */
function formatCondition(value) {
	if (!value || value === "any") return "Any";
	if (Array.isArray(value)) return value.map(titleCase).join(", ");
	return titleCase(value);
}
/** [0.1, 0.6] -> "0.1–0.6 kg" (collapses to a single value when min === max) */
function formatRange([min, max], unit) {
	const fmt = (n) => Number.isInteger(n) ? n.toString() : n.toFixed(2);
	return min === max ? `${fmt(min)} ${unit}` : `${fmt(min)}–${fmt(max)} ${unit}`;
}
/** 0.07 -> "+7%" | 0.055 -> "+5.5%" */
function formatPercent(value) {
	const pct = value * 100;
	return `+${Math.round(pct * 100) / 100}%`;
}
/** 25 -> "+25" (for flat, non-percentage skill/enchant values) */
function formatFlat(value) {
	return `+${value}`;
}
//#endregion
export { titleCase as a, formatRange as i, formatFlat as n, formatPercent as r, formatCondition as t };
