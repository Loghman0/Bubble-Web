import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { d as Medal, h as Crown, i as Sparkles, r as Users, s as RefreshCw, v as CircleAlert } from "../_libs/lucide-react.mjs";
import { a as Reveal, i as RarityBadge, n as EmptyState, r as PageHeader, t as AnimatedCounter } from "./primitives-wvDVhHFR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leaderboard-yYoMvAA7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
var API_BASE = ({
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_BUBBLE_API_URL"] || "").trim().replace(/\/$/, "");
/** True when an API origin has been configured at build time. */
var isLiveApiConfigured = API_BASE.length > 0;
/**
* A localhost origin only works while you run the site and the bot API on the
* same machine. Anyone else's browser cannot reach it.
*/
var isLocalOnlyApi = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:|\/|$)/i.test(API_BASE);
var LiveApiError = class extends Error {
	kind;
	constructor(kind, message) {
		super(message);
		this.name = "LiveApiError";
		this.kind = kind;
	}
};
var TIMEOUT_MS = 1e4;
async function getJson(path) {
	if (!isLiveApiConfigured) throw new LiveApiError("unconfigured", "No live API origin is configured (VITE_BUBBLE_API_URL).");
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
	let res;
	try {
		res = await fetch(`${API_BASE}${path}`, {
			signal: controller.signal,
			headers: { Accept: "application/json" }
		});
	} catch {
		throw new LiveApiError("network", isLocalOnlyApi ? "The API origin is a localhost address, which only works on the machine running the bot." : "The live API did not respond. It may be offline, blocked by CORS, or unreachable.");
	} finally {
		clearTimeout(timer);
	}
	if (!res.ok) throw new LiveApiError("http", `The live API replied with ${res.status} ${res.statusText}.`);
	const text = await res.text();
	try {
		return JSON.parse(text);
	} catch {
		throw new LiveApiError("parse", "The live API returned something that is not JSON (usually an error or login page).");
	}
}
var liveApi = {
	stats: () => getJson("/api/public/stats"),
	leaderboard: (by = "level", limit = 25) => getJson(`/api/public/leaderboard?by=${by}&limit=${limit}`),
	recentCatches: (limit = 20) => getJson(`/api/public/catches/recent?limit=${limit}`),
	rarestCatches: (limit = 20) => getJson(`/api/public/catches/rarest?limit=${limit}`),
	servers: (limit = 24) => getJson(`/api/public/servers?limit=${limit}`)
};
/** Small pulsing "Live" indicator for widgets backed by useLivePoll. */
function LiveIndicator({ className, updatedAt, offline = false }) {
	if (offline) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "size-2 rounded-full bg-muted-foreground/60",
			"aria-hidden": true
		}), "Offline"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 text-xs font-medium", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative flex size-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-75" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-flex size-2 rounded-full bg-emerald-500" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-emerald-400",
				children: "Live"
			}),
			updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-muted-foreground",
				children: [
					"· updated",
					" ",
					new Date(updatedAt).toLocaleTimeString([], {
						hour: "2-digit",
						minute: "2-digit"
					})
				]
			}) : null
		]
	});
}
/**
* Shown when a live widget has no data. Explains *why* in plain language —
* the most common cause by far is that VITE_BUBBLE_API_URL is unset or points
* at localhost, which a visitor's browser can never reach.
*/
function LiveError({ message, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass flex flex-col items-center gap-3 rounded-2xl px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
				className: "size-6 text-destructive",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-foreground",
					children: "Live data is offline"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-1 max-w-md text-sm text-muted-foreground",
					children: !isLiveApiConfigured ? "The site has no live API address configured yet, so there is nothing to read from." : isLocalOnlyApi ? "The configured API address is a localhost address. That only works while the bot API and this site run on the same computer — set VITE_BUBBLE_API_URL to a public https:// address." : "The bot API is unreachable from your browser. It may be offline, or it may need to allow requests from this site (CORS)."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted-foreground/70",
					children: message
				})
			] }),
			onRetry ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				onClick: onRetry,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
					className: "size-4",
					"aria-hidden": true
				}), " Try again"]
			}) : null
		]
	});
}
function LiveSkeletonRows({ rows = 6 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: Array.from({ length: rows }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full rounded-lg" }, i))
	});
}
/**
* Fetches once immediately, then re-fetches on an interval. Used by every
* live widget (leaderboard, catch feeds, stats strip) so they all share the
* same loading/error/refresh behavior instead of each hand-rolling it.
*
* Ignores results from stale in-flight requests (e.g. if the poll interval
* fires again before a slow request resolves, or deps change mid-request) so
* a slow response can never clobber newer data.
*/
function useLivePoll(fetcher, { intervalMs = 2e4, deps = [], enabled = true } = {}) {
	const [state, setState] = (0, import_react.useState)({
		data: null,
		error: null,
		loading: enabled,
		updatedAt: null
	});
	const requestId = (0, import_react.useRef)(0);
	const fetcherRef = (0, import_react.useRef)(fetcher);
	fetcherRef.current = fetcher;
	const load = () => {
		if (!enabled) return;
		const id = ++requestId.current;
		setState((prev) => ({
			...prev,
			loading: true
		}));
		fetcherRef.current().then((data) => {
			if (id !== requestId.current) return;
			setState({
				data,
				error: null,
				loading: false,
				updatedAt: Date.now()
			});
		}).catch((err) => {
			if (id !== requestId.current) return;
			setState((prev) => ({
				data: prev.data,
				updatedAt: prev.updatedAt,
				error: err instanceof Error ? err.message : "Failed to load live data.",
				loading: false
			}));
		});
	};
	(0, import_react.useEffect)(() => {
		if (!enabled) {
			setState((prev) => ({
				...prev,
				loading: false
			}));
			return;
		}
		load();
		const timer = setInterval(load, intervalMs);
		return () => clearInterval(timer);
	}, [
		intervalMs,
		enabled,
		...deps
	]);
	return {
		...state,
		refresh: load
	};
}
function timeAgo(iso) {
	const seconds = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1e3));
	if (seconds < 60) return "just now";
	const minutes = Math.floor(seconds / 60);
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	return `${Math.floor(hours / 24)}d ago`;
}
function CatchRow({ entry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center gap-3 rounded-xl border border-border/60 bg-card/40 px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-2xl",
				"aria-hidden": true,
				children: entry.isMutant ? "🧬" : "🐟"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-semibold",
							children: entry.fishName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: entry.rarityLabel }),
						entry.isMutant ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 text-xs font-medium text-fuchsia-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "size-3",
								"aria-hidden": true
							}), " Mutant"]
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 truncate text-sm text-muted-foreground",
					children: [
						"Caught by ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: entry.caughtByUsername
						}),
						entry.serverName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							" ",
							"in ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: entry.serverName
							})
						] }) : null,
						" · ",
						entry.weight,
						"kg"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-xs text-muted-foreground",
				children: timeAgo(entry.caughtAt)
			})
		]
	});
}
function CatchFeed({ mode }) {
	const { data, error, loading, updatedAt, refresh } = useLivePoll(() => mode === "recent" ? liveApi.recentCatches(15) : liveApi.rarestCatches(15), {
		intervalMs: 15e3,
		deps: [mode]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-bold",
					children: mode === "recent" ? "Latest Catches" : "Rarest Catches"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveIndicator, {
					updatedAt,
					offline: Boolean(error) && !data
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: mode === "recent" ? "Rare-or-better fish landed across every server, as they happen." : "The single rarest catches from the last 30 days, server-wide."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveSkeletonRows, { rows: 6 }) : error && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveError, {
					message: error,
					onRetry: refresh
				}) : !data || data.catches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Nothing yet",
					description: "Rare-or-better catches will show up here as soon as someone lands one."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: data.catches.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchRow, { entry: c }, `${c.fishId}-${c.caughtAt}-${i}`))
				})
			})
		]
	});
}
var Table = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-sm", className),
		...props
	})
}));
Table.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
	ref,
	className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
	...props
}));
TableFooter.displayName = "TableFooter";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
	ref,
	className: cn("h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableCell.displayName = "TableCell";
var TableCaption = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
	ref,
	className: cn("mt-4 text-sm text-muted-foreground", className),
	...props
}));
TableCaption.displayName = "TableCaption";
var SORT_OPTIONS = [
	{
		value: "level",
		label: "Top Level",
		column: "Level"
	},
	{
		value: "coins",
		label: "Richest (Coins)",
		column: "Coins"
	},
	{
		value: "coinsEarned",
		label: "Lifetime Coins Earned",
		column: "Lifetime Coins"
	},
	{
		value: "catches",
		label: "Most Fish Caught",
		column: "Fish Caught"
	}
];
var rankIcon = (rank) => {
	if (rank === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, {
		className: "size-4 text-amber-400",
		"aria-hidden": true
	});
	if (rank === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, {
		className: "size-4 text-slate-300",
		"aria-hidden": true
	});
	if (rank === 3) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medal, {
		className: "size-4 text-amber-700",
		"aria-hidden": true
	});
	return null;
};
function LeaderboardTable() {
	const [sort, setSort] = (0, import_react.useState)("level");
	const { data, error, loading, updatedAt, refresh } = useLivePoll(() => liveApi.leaderboard(sort, 25), {
		intervalMs: 2e4,
		deps: [sort]
	});
	const activeOption = SORT_OPTIONS.find((o) => o.value === sort);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-bold",
					children: "Leaderboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveIndicator, {
					updatedAt,
					offline: Boolean(error) && !data
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: sort,
				onValueChange: (v) => setSort(v),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[220px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: SORT_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: o.value,
					children: o.label
				}, o.value)) })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveSkeletonRows, { rows: 8 }) : error && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveError, {
				message: error,
				onRetry: refresh
			}) : !data || data.players.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No anglers yet",
				description: "Once players start fishing, they'll show up here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-12",
					children: "#"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Angler" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "text-right",
					children: activeOption.column
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: data.players.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
				className: cn(p.rank <= 3 && "bg-primary/5"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-mono text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [rankIcon(p.rank), p.rank]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: p.username
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						className: "text-right tabular-nums",
						children: [
							sort === "level" && `Lv. ${p.level}`,
							sort === "coins" && p.coins.toLocaleString(),
							sort === "coinsEarned" && p.totalCoinsEarned.toLocaleString(),
							sort === "catches" && p.totalCaught.toLocaleString()
						]
					})
				]
			}, `${p.rank}-${p.username}`)) })] })
		})]
	});
}
function initials(name) {
	return name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase() ?? "").join("") || "?";
}
function ServerDirectory({ limit = 24 }) {
	const { data, error, loading, updatedAt, refresh } = useLivePoll(() => liveApi.servers(limit), { intervalMs: 6e4 });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-bold",
					children: "Servers Using Bubble"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveIndicator, {
					updatedAt,
					offline: Boolean(error) && !data
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "A sample of Discord servers currently running Bubble. Server owners can opt out of this list any time."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveSkeletonRows, { rows: 4 }) : error && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveError, {
					message: error,
					onRetry: refresh
				}) : !data || data.servers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No servers yet",
					description: "Servers running Bubble will be listed here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: data.servers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-xl border border-border/60 bg-card/40 px-4 py-3",
						children: [s.iconUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: s.iconUrl,
							alt: "",
							className: "size-10 shrink-0 rounded-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-lagoon to-primary text-sm font-bold text-primary-foreground",
							children: initials(s.name)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
										className: "size-3",
										"aria-hidden": true
									}),
									s.memberCount.toLocaleString(),
									" members"
								]
							})]
						})]
					}, s.name))
				})
			})
		]
	});
}
function LiveStatsStrip() {
	const { data, error, loading, updatedAt } = useLivePoll(() => liveApi.stats(), {
		intervalMs: 3e4,
		enabled: isLiveApiConfigured
	});
	if (!isLiveApiConfigured) return null;
	if (loading && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveSkeletonRows, { rows: 1 });
	if (error && !data) return null;
	if (!data) return null;
	const items = [
		{
			label: "Anglers",
			value: data.players
		},
		{
			label: "Servers",
			value: data.servers
		},
		{
			label: "Fish Caught",
			value: data.totalFishCaught
		},
		{
			label: "Fish Species",
			value: data.fishSpecies
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl p-5 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.2em] text-primary uppercase",
				children: "Right Now In Bubble"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveIndicator, { updatedAt })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-2xl font-bold sm:text-3xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedCounter, {
					value: item.value,
					suffix: item.suffix
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs text-muted-foreground sm:text-sm",
				children: item.label
			})] }, item.label))
		})]
	});
}
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function LeaderboardPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Live",
				title: "Leaderboard & Live Stats",
				description: "Real player data, straight from the bot. Updates automatically — no need to refresh."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveStatsStrip, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .05,
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					defaultValue: "leaderboard",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
							className: "grid w-full grid-cols-2 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "leaderboard",
									children: "Leaderboard"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "recent",
									children: "Latest Catches"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "rarest",
									children: "Rarest Catches"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "servers",
									children: "Servers"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "leaderboard",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeaderboardTable, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "recent",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchFeed, { mode: "recent" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "rarest",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchFeed, { mode: "rarest" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "servers",
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServerDirectory, {})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .1,
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-sm text-muted-foreground",
					children: [
						"Only your Discord username and the server a catch happened in are ever shown here — never your Discord ID. Run ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded bg-muted px-1.5 py-0.5",
							children: ".privacy hide"
						}),
						" ",
						"in Discord to opt out any time. See the",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/privacy",
							className: "underline underline-offset-4",
							children: "Privacy Policy"
						}),
						" ",
						"for details."
					]
				})
			})
		]
	});
}
//#endregion
export { LeaderboardPage as component };
