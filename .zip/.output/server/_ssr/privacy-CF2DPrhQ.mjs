import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { r as PageHeader } from "./primitives-wvDVhHFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-CF2DPrhQ.js
var import_jsx_runtime = require_jsx_runtime();
var sections = [
	["What we store", "Bubble stores your Discord user ID, server IDs where you play, and your game progress: currencies, catches, museum donations, pets, rods, quests, and guild membership."],
	["What we do not store", "Bubble does not store message content, direct messages, email addresses, payment details, or IP addresses."],
	["Why we store it", "Game state must persist between commands. Data is never sold, rented, or shared with advertisers."],
	["Retention", "Progress is kept while your account is active. Accounts inactive for 24 months are purged automatically."],
	["Deletion requests", "Ask in the support server or email hello@bubble.gg from an address you can verify. Deletion is permanent and removes all progress."],
	["Third parties", "Bubble runs on standard cloud hosting and communicates only with Discord's API. No analytics vendors receive your game data."],
	["Children", "Bubble follows Discord's minimum age requirements for your region."],
	["Changes", "Material changes to this policy are announced in the support server before they take effect."]
];
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Legal",
			title: "Privacy Policy",
			description: "Last updated 9 August 2026."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 space-y-8",
			children: sections.map(([h, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-bold",
				children: h
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: b
			})] }, h))
		})]
	});
}
//#endregion
export { PrivacyPage as component };
