import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as wikiArticles } from "./content-CICGCk7H.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-CBlPtzp6.mjs";
import { a as Reveal } from "./primitives-wvDVhHFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wiki._slug-f1r9OBW1.js
var import_jsx_runtime = require_jsx_runtime();
var slugifyHeading = (heading) => heading.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
/** Renders `inline code` spans from the plain-text article body. */
function RichText({ text }) {
	const parts = text.split(/(`[^`]+`)/g);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 leading-relaxed text-muted-foreground",
		children: parts.map((part, i) => part.startsWith("`") && part.endsWith("`") && part.length > 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-md bg-muted/60 px-1.5 py-0.5 font-mono text-[0.85em] text-foreground",
			children: part.slice(1, -1)
		}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, i))
	});
}
function WikiArticlePage() {
	const { entry: a } = Route.useLoaderData();
	const index = wikiArticles.findIndex((x) => x.slug === a.slug);
	const prev = index > 0 ? wikiArticles[index - 1] : void 0;
	const next = index < wikiArticles.length - 1 ? wikiArticles[index + 1] : void 0;
	const related = (a.related ?? []).map((slug) => wikiArticles.find((x) => x.slug === slug)).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-[1fr_220px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						"aria-label": "Breadcrumb",
						className: "text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/wiki",
								className: "hover:text-foreground",
								children: "Wiki"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: " / "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: a.category
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-6 font-display text-3xl font-bold sm:text-4xl",
							children: a.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg text-muted-foreground",
							children: a.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 space-y-10",
							children: a.sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								id: slugifyHeading(s.heading),
								className: "scroll-mt-24",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl font-bold",
									children: s.heading
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: s.body })]
							}, s.heading))
						})
					] }),
					a.slug === "rods-and-enchants" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/enchants",
							className: "glass inline-flex items-center rounded-xl px-4 py-2 text-sm font-semibold text-primary hover:underline",
							children: "Browse every enchant and its book art →"
						})
					}) : null,
					related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-14 border-t border-border/60 pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Related articles"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-3 sm:grid-cols-2",
							children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/wiki/$slug",
								params: { slug: r.slug },
								className: "glass block rounded-2xl p-4 transition-transform hover:-translate-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-sm font-bold",
									children: r.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: r.summary
								})]
							}) }, r.slug))
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						"aria-label": "Article navigation",
						className: "mt-12 flex flex-wrap justify-between gap-3 border-t border-border/60 pt-6 text-sm",
						children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/wiki/$slug",
							params: { slug: prev.slug },
							className: "text-muted-foreground hover:text-foreground",
							children: ["← ", prev.title]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/wiki/$slug",
							params: { slug: next.slug },
							className: "text-muted-foreground hover:text-foreground",
							children: [next.title, " →"]
						}) : null]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-semibold tracking-widest text-muted-foreground uppercase",
						children: "On this page"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 text-sm",
						children: a.sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `#${slugifyHeading(s.heading)}`,
							className: "block rounded-lg px-3 py-1.5 text-muted-foreground transition-colors hover:bg-muted/50 hover:text-foreground",
							children: s.heading
						}) }, s.heading))
					})]
				})
			})]
		})
	});
}
//#endregion
export { WikiArticlePage as component };
