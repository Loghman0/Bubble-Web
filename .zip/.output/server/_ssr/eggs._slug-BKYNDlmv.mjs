import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { a as petsForEgg } from "./pets-zZN8Pgm8.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Route$10 } from "./router-CBlPtzp6.mjs";
import { a as Reveal, i as RarityBadge } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/eggs._slug-BKYNDlmv.js
var import_jsx_runtime = require_jsx_runtime();
function EggDetail() {
	const { entry: e } = Route$10.useLoaderData();
	const hatchable = petsForEgg(e);
	const dropWeights = e.dropWeights;
	const totalWeight = Object.values(dropWeights).reduce((sum, w) => sum + w, 0);
	const rarityRows = Object.entries(dropWeights).sort(([, a], [, b]) => b - a);
	const capitalize = (r) => r.charAt(0).toUpperCase() + r.slice(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Breadcrumb",
			className: "text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/eggs",
					className: "hover:text-foreground",
					children: "Eggs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: " / "
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: e.name
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 md:grid-cols-[300px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
				src: e.image,
				alt: e.name,
				className: "from-treasure/20"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .08,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-bold sm:text-4xl",
						children: e.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-muted-foreground",
						children: [
							"Hatch this egg in Discord for a chance at one of its ",
							hatchable.length,
							" possible companions."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid gap-2 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Price"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-semibold",
									children: [
										e.price.toLocaleString(),
										" ",
										e.currency
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Base Hatch XP"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-semibold",
									children: e.baseHatchXp.toLocaleString()
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "Hatch XP / Player Level"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
									className: "font-semibold",
									children: ["+", e.hatchXpPerLevel]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted-foreground",
									children: "In-game id"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-semibold",
									children: e.key
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: "Total XP needed to hatch scales with your player level: base hatch XP + (hatch XP per level × your level)."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 font-display text-lg font-bold",
						children: "Hatch Odds by Rarity"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: rarityRows.map(([rarity, weight]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass flex items-center justify-between gap-4 rounded-xl px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: capitalize(rarity) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "font-semibold",
								children: [(weight / totalWeight * 100).toFixed(1), "%"]
							})]
						}, rarity))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 font-display text-lg font-bold",
						children: "Possible Companions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-2",
						children: hatchable.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/pets/$slug",
							params: { slug: p.slug },
							className: "glass inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm hover:text-primary",
							children: [p.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, {
								rarity: p.rarity,
								className: "ml-1"
							})]
						}) }, p.slug))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 glass rounded-xl px-4 py-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold mb-2",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: e.description
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/eggs",
								children: "Back to eggs"
							})
						})
					})
				]
			})]
		})]
	});
}
//#endregion
export { EggDetail as component };
