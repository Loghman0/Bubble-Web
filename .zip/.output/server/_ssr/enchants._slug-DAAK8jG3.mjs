import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as enchants } from "./enchants-X3Es6ort.mjs";
import { r as rods } from "./rods-DB3oDwAf.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Route$8 } from "./router-CBlPtzp6.mjs";
import { a as Reveal } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
import { a as titleCase, r as formatPercent } from "./game-format-D6teHOEi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enchants._slug-DAAK8jG3.js
var import_jsx_runtime = require_jsx_runtime();
var LEVEL_LABELS = [
	"I",
	"II",
	"III"
];
function EnchantDetail() {
	const { entry: e } = Route$8.useLoaderData();
	const index = enchants.findIndex((x) => x.slug === e.slug);
	const prev = index > 0 ? enchants[index - 1] : void 0;
	const next = index < enchants.length - 1 ? enchants[index + 1] : void 0;
	const compatibleRods = rods.filter((r) => (r.enchantSlots ?? 0) > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Breadcrumb",
				className: "text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/enchants",
						className: "hover:text-foreground",
						children: "Enchants"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: " / "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: e.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-8 sm:grid-cols-[160px_1fr] sm:items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-40 sm:mx-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
						src: e.image,
						alt: `${e.name} enchantment book`
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-bold sm:text-4xl",
						children: e.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg text-muted-foreground",
						children: e.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-5 flex flex-wrap gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass rounded-full px-3 py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline text-muted-foreground",
									children: "Affects: "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline font-medium",
									children: titleCase(e.appliesTo)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass rounded-full px-3 py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline text-muted-foreground",
									children: "Levels: "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline font-medium",
									children: "3"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass rounded-full px-3 py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline text-muted-foreground",
									children: "Max bonus: "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline font-medium text-primary",
									children: formatPercent(e.valuePerLevel[2])
								})]
							})
						]
					})
				] })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .05,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-12 font-display text-xl font-bold",
					children: "Levels"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-4 sm:grid-cols-3",
					children: e.levelImages.map((img, li) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "glass rounded-2xl p-5 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto w-24",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
									src: img,
									alt: `${e.name} level ${LEVEL_LABELS[li]} book`
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs font-semibold tracking-widest text-muted-foreground uppercase",
								children: ["Level ", LEVEL_LABELS[li]]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-xl font-bold text-primary",
								children: formatPercent(e.valuePerLevel[li])
							})
						]
					}, li))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .1,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-12 font-display text-xl font-bold",
						children: "How to get it"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 list-disc space-y-1 pl-5 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Treasure chests found while fishing." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Guild raid rewards." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "High-level quest rewards." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The Museum Shop, in exchange for Ancient Museum Coins." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 font-display text-xl font-bold",
						children: "Slot rules"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground",
						children: "Enchants apply to a specific owned rod, not to your account — switching rods means starting over on that rod. A rod can hold as many enchants as it has enchant slots, and the same enchant can never be applied twice to one rod."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-6 font-display text-base font-bold",
						children: "Rods with enchant slots"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-2",
						children: compatibleRods.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/rods/$slug",
							params: { slug: r.slug },
							className: "glass inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm hover:text-primary",
							children: [r.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [r.enchantSlots, " slots"]
							})]
						}) }, r.slug))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": "Enchant navigation",
				className: "mt-14 flex flex-wrap justify-between gap-3 border-t border-border/60 pt-6 text-sm",
				children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/enchants/$slug",
					params: { slug: prev.slug },
					className: "text-muted-foreground hover:text-foreground",
					children: ["← ", prev.name]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/enchants/$slug",
					params: { slug: next.slug },
					className: "text-muted-foreground hover:text-foreground",
					children: [next.name, " →"]
				}) : null]
			})
		]
	});
}
//#endregion
export { EnchantDetail as component };
