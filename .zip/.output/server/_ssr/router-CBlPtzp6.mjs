import { n as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { n as baits, t as baitBySlug } from "./baits-DPjlVlb7.mjs";
import { n as enchants, t as enchantBySlug } from "./enchants-X3Es6ort.mjs";
import { n as fish, r as fishBySlug, t as RARITIES } from "./game-BJe2xpyU.mjs";
import { i as pets, n as eggs, r as petBySlug, t as eggBySlug } from "./pets-zZN8Pgm8.mjs";
import { r as rods, t as rodBySlug } from "./rods-DB3oDwAf.mjs";
import { r as wikiBySlug, t as faq } from "./content-CICGCk7H.mjs";
import { L as notFound, _ as Link, f as createRouter, g as createRootRouteWithContext, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { S as Check, _ as Circle, b as ChevronRight, l as MessagesSquare, p as ExternalLink, t as X, u as Menu, x as ChevronDown } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Label2, c as Root2, d as SubTrigger2, f as Trigger, i as ItemIndicator2, l as Separator2, n as Content2, o as Portal2, r as Item2, s as RadioItem2, t as CheckboxItem2, u as SubContent2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/seo-uN8RFmzX.js
function pageMeta(title, description) {
	return [
		{ title },
		{
			name: "description",
			content: description
		},
		{
			property: "og:title",
			content: title
		},
		{
			property: "og:description",
			content: description
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	];
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CBlPtzp6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-DIiCopOD.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var DISCORD_URL = "https://discord.gg/PGbQFCFTC2";
var INVITE_URL = "https://discord.com/oauth2/authorize?client_id=1314851118840414300&permissions=4504288969967680&integration_type=0&scope=bot";
var primary = [
	{
		label: "Home",
		to: "/"
	},
	{
		label: "Features",
		to: "/features"
	},
	{
		label: "Wiki",
		to: "/wiki"
	}
];
var groups = [{
	label: "Encyclopedia",
	links: [
		{
			label: "Fish Encyclopedia",
			to: "/fish"
		},
		{
			label: "Pets",
			to: "/pets"
		},
		{
			label: "Eggs",
			to: "/eggs"
		},
		{
			label: "Rods",
			to: "/rods"
		},
		{
			label: "Baits",
			to: "/baits"
		},
		{
			label: "Enchants",
			to: "/enchants"
		}
	]
}, {
	label: "More",
	links: [
		{
			label: "FAQ",
			to: "/faq"
		},
		{
			label: "Privacy Policy",
			to: "/privacy"
		},
		{
			label: "Terms of Service",
			to: "/terms"
		}
	]
}];
var allLinks = [...primary, ...groups.flatMap((g) => g.links)];
var activeProps = { className: "text-primary" };
function Navbar() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-50 w-full border-b border-border/60 bg-background/70 backdrop-blur-xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Main navigation",
			className: "mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 font-display text-lg font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-lagoon to-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/bubble.png",
							alt: "",
							className: "size-7 object-contain"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient-ocean",
						children: "Bubble"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-1 lg:flex",
					children: [primary.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						activeOptions: { exact: l.to === "/" },
						activeProps,
						className: "rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
						children: l.label
					}, l.to)), groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuTrigger, {
						className: "flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
						children: [g.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
							className: "size-3.5",
							"aria-hidden": true
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
						align: "start",
						className: "w-56",
						children: g.links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: l.to,
								activeProps,
								children: l.label
							})
						}, l.to))
					})] }, g.label))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							variant: "ghost",
							className: "hidden sm:inline-flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: DISCORD_URL,
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesSquare, {
									className: "size-4",
									"aria-hidden": true
								}), " Discord"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "sm",
							className: "hidden sm:inline-flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: INVITE_URL,
								target: "_blank",
								rel: "noreferrer",
								children: ["Invite Bubble ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
									className: "size-4",
									"aria-hidden": true
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
							open,
							onOpenChange: setOpen,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									className: "lg:hidden",
									"aria-label": "Open menu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
										className: "size-5",
										"aria-hidden": true
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
								side: "right",
								className: "w-[300px] overflow-y-auto",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
										className: "font-display",
										children: "Navigation"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-6 space-y-1",
										children: allLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: l.to,
											activeOptions: { exact: l.to === "/" },
											activeProps,
											onClick: () => setOpen(false),
											className: "block rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
											children: l.label
										}) }, l.to))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 flex flex-col gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: INVITE_URL,
												target: "_blank",
												rel: "noreferrer",
												children: "Invite Bubble"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "outline",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: DISCORD_URL,
												target: "_blank",
												rel: "noreferrer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesSquare, {
													className: "size-4",
													"aria-hidden": true
												}), " Join our Discord"]
											})
										})]
									})
								]
							})]
						})
					]
				})
			]
		})
	});
}
var columns = [
	{
		title: "Game",
		links: [
			{
				label: "Features",
				to: "/features"
			},
			{
				label: "Fish Encyclopedia",
				to: "/fish"
			},
			{
				label: "Pets",
				to: "/pets"
			},
			{
				label: "Eggs",
				to: "/eggs"
			}
		]
	},
	{
		title: "Gear",
		links: [
			{
				label: "Rods",
				to: "/rods"
			},
			{
				label: "Baits",
				to: "/baits"
			},
			{
				label: "Enchants",
				to: "/enchants"
			}
		]
	},
	{
		title: "Resources",
		links: [
			{
				label: "Wiki",
				to: "/wiki"
			},
			{
				label: "FAQ",
				to: "/faq"
			},
			{
				label: "Privacy Policy",
				to: "/privacy"
			},
			{
				label: "Terms of Service",
				to: "/terms"
			}
		]
	}
];
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-24 border-t border-border/60 bg-deep/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_repeat(3,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 font-display text-lg font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-lagoon to-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/bubble.png",
							alt: "",
							className: "size-7 object-contain"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient-ocean",
						children: "Bubble"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-sm text-sm text-muted-foreground",
					children: "A fishing MMORPG that lives inside Discord. Collect species, upgrade your gear, and hatch companions with your server."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: INVITE_URL,
							target: "_blank",
							rel: "noreferrer",
							children: "Invite Bubble"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: DISCORD_URL,
							target: "_blank",
							rel: "noreferrer",
							children: "Join our Discord"
						})
					})]
				})
			] }), columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				"aria-label": c.title,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-sm font-bold tracking-wide uppercase",
					children: c.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: c.links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						className: "text-sm text-muted-foreground transition-colors hover:text-foreground",
						children: l.label
					}) }, l.to))
				})]
			}, c.title))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border/60 py-6 text-center text-xs text-muted-foreground",
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Bubble. Not affiliated with Discord Inc."
			]
		})]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$20 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Bubble — Discord Fishing MMORPG" },
			{
				name: "description",
				content: "Bubble is a cozy ocean fishing MMORPG for Discord. Catch fish, hatch pets, curate a museum, and raid with your guild."
			},
			{
				property: "og:site_name",
				content: "Bubble"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:image",
				content: "/bubble.png"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:image",
				content: "/bubble.png"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "apple-touch-icon",
				href: "/bubble.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito+Sans:wght@400;500;600;700&display=swap"
			}
		],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "VideoGame",
				name: "Bubble",
				genre: ["MMORPG", "Fishing"],
				gamePlatform: "Discord",
				description: "A cozy ocean fishing MMORPG played entirely through Discord slash commands."
			})
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$20.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-dvh flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#main",
					className: "sr-only rounded-md bg-primary px-4 py-2 text-primary-foreground focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-[60]",
					children: "Skip to content"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					id: "main",
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
			]
		})
	});
}
/**
* Content counts derived from the real roster. No player, server, or
* economy figures are published here — those live inside the bot.
*/
var rosterCounts = {
	fish: fish.length,
	rods: rods.length,
	baits: baits.length,
	pets: pets.length,
	eggs: eggs.length,
	enchants: enchants.length,
	rarities: RARITIES.length
};
var fishCountByRarity = RARITIES.map((rarity) => ({
	rarity,
	count: fish.filter((f) => f.rarity === rarity).length
}));
var $$splitComponentImporter$19 = () => import("./routes-CIgdqM6g.mjs");
var Route$19 = createFileRoute("/")({
	head: () => ({
		meta: pageMeta("Bubble — Discord Fishing MMORPG", `Bubble is a fishing MMORPG that lives inside Discord: ${rosterCounts.fish} species across ${rosterCounts.rarities} rarity tiers, ${rosterCounts.rods} rods, ${rosterCounts.baits} baits, ${rosterCounts.pets} pets, ${rosterCounts.eggs} eggs and ${rosterCounts.enchants} enchants.`),
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./faq-BDUO_3X8.mjs");
var Route$18 = createFileRoute("/faq")({
	head: () => ({
		meta: pageMeta("FAQ — Bubble Questions Answered", "Answers about getting started, fishing, pets, the museum, guilds, eggs, the economy, and enchants in Bubble."),
		links: [{
			rel: "canonical",
			href: "/faq"
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "FAQPage",
				mainEntity: faq.flatMap((g) => g.items.map((i) => ({
					"@type": "Question",
					name: i.q,
					acceptedAnswer: {
						"@type": "Answer",
						text: i.a
					}
				})))
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./features-CBYfEey7.mjs");
var Route$17 = createFileRoute("/features")({
	head: () => ({
		meta: pageMeta("Features — Bubble Fishing MMORPG", `Bubble's content at a glance: nine rarity tiers, 107 fish species, ${rods.length} rods, ${baits.length} baits, ${pets.length} pets, ${eggs.length} eggs, ${enchants.length} enchants and three currencies.`),
		links: [{
			rel: "canonical",
			href: "/features"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./leaderboard-yYoMvAA7.mjs");
var Route$16 = createFileRoute("/leaderboard")({
	head: () => ({
		meta: pageMeta("Live Leaderboard — Bubble", "Real-time Bubble leaderboard: top anglers, the latest and rarest catches server-wide, and every Discord server running Bubble."),
		links: [{
			rel: "canonical",
			href: "/leaderboard"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./privacy-CF2DPrhQ.mjs");
var Route$15 = createFileRoute("/privacy")({
	head: () => ({
		meta: pageMeta("Privacy Policy — Bubble", "What data Bubble stores, why it is stored, how long it is kept, and how to request deletion."),
		links: [{
			rel: "canonical",
			href: "/privacy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./terms-BFJhUGcO.mjs");
var Route$14 = createFileRoute("/terms")({
	head: () => ({
		meta: pageMeta("Terms of Service — Bubble", "The rules for using Bubble: acceptable use, account handling, virtual items, availability, and liability."),
		links: [{
			rel: "canonical",
			href: "/terms"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./baits.index-CK_dxobs.mjs");
var Route$13 = createFileRoute("/baits/")({
	head: () => ({
		meta: pageMeta("Baits — Bubble Bait Catalogue", "All twelve Bubble baits, grouped from beginner worms to master-tier magical dust."),
		links: [{
			rel: "canonical",
			href: "/baits"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./baits._slug-ac_eNRSX.mjs");
var Route$12 = createFileRoute("/baits/$slug")({
	loader: ({ params }) => {
		const entry = baitBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Bait not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const b = loaderData.entry;
		return {
			meta: pageMeta(`${b.name} — Baits — Bubble`, `${b.name} is a fishing bait in Bubble, the Discord fishing MMORPG.`),
			links: [{
				rel: "canonical",
				href: `/baits/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./eggs.index-lfiYleBP.mjs");
var Route$11 = createFileRoute("/eggs/")({
	head: () => ({
		meta: pageMeta("Eggs — Bubble Hatching Guide", "The three Bubble eggs — Common, Rare and Ancient — and the companions they hatch."),
		links: [{
			rel: "canonical",
			href: "/eggs"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./eggs._slug-BKYNDlmv.mjs");
var Route$10 = createFileRoute("/eggs/$slug")({
	loader: ({ params }) => {
		const entry = eggBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Egg not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const e = loaderData.entry;
		return {
			meta: pageMeta(`${e.name} — Eggs — Bubble`, `${e.name} is one of the three eggs in Bubble, the Discord fishing MMORPG. Hatch it for a companion.`),
			links: [{
				rel: "canonical",
				href: `/eggs/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./enchants.index-G6Ye8rCB.mjs");
var Route$9 = createFileRoute("/enchants/")({
	head: () => ({
		meta: pageMeta("Enchants — Bubble Rod Enchanting Guide", `All ${enchants.length} rod enchants in Bubble, the Discord fishing MMORPG, with their exact bonus at level I, II and III.`),
		links: [{
			rel: "canonical",
			href: "/enchants"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./enchants._slug-DAAK8jG3.mjs");
var Route$8 = createFileRoute("/enchants/$slug")({
	loader: ({ params }) => {
		const entry = enchantBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Enchant not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const e = loaderData.entry;
		return {
			meta: pageMeta(`${e.name} — Enchants — Bubble`, `${e.name}: ${e.description} Exact bonus at level I, II and III in Bubble, the Discord fishing MMORPG.`),
			links: [{
				rel: "canonical",
				href: `/enchants/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./fish.index-DAG7Pw4Z.mjs");
var Route$7 = createFileRoute("/fish/")({
	head: () => ({
		meta: pageMeta("Fish Encyclopedia — Bubble", "Browse every species in Bubble: 107 fish across nine rarity tiers, from Common to Divine."),
		links: [{
			rel: "canonical",
			href: "/fish"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./fish._slug-BDB3_6_U.mjs");
var Route$6 = createFileRoute("/fish/$slug")({
	loader: ({ params }) => {
		const entry = fishBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Species not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const f = loaderData.entry;
		return {
			meta: pageMeta(`${f.name} — Fish Encyclopedia — Bubble`, `${f.name} is a ${f.rarity} species in Bubble, the Discord fishing MMORPG.`),
			links: [{
				rel: "canonical",
				href: `/fish/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./pets.index-BKbZKRDl.mjs");
var Route$5 = createFileRoute("/pets/")({
	head: () => ({
		meta: pageMeta("Pets — Bubble Companion Index", `All ${pets.length} Bubble companions, from the Parrot and Otter to the Kraken Hatchling, Dragon and Void Wisp.`),
		links: [{
			rel: "canonical",
			href: "/pets"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./pets._slug-bxWhVCNg.mjs");
/** Skill categories whose skillValue is a flat stat point rather than a percentage. */
var Route$4 = createFileRoute("/pets/$slug")({
	loader: ({ params }) => {
		const entry = petBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Pet not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const p = loaderData.entry;
		return {
			meta: pageMeta(`${p.name} — Pets — Bubble`, `${p.name} is one of the ${pets.length} companions you can hatch in Bubble, the Discord fishing MMORPG.`),
			links: [{
				rel: "canonical",
				href: `/pets/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./rods.index-x3cLh10I.mjs");
var Route$3 = createFileRoute("/rods/")({
	head: () => ({
		meta: pageMeta("Rods — Bubble Gear Catalogue", "All nine Bubble fishing rods, grouped into Beginner, Journeyman and Master tiers."),
		links: [{
			rel: "canonical",
			href: "/rods"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./rods._slug-FBJTtWND.mjs");
var Route$2 = createFileRoute("/rods/$slug")({
	loader: ({ params }) => {
		const entry = rodBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Rod not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const r = loaderData.entry;
		return {
			meta: pageMeta(`${r.name} — Rods — Bubble`, `${r.name} is a ${r.tier}-tier fishing rod in Bubble, the Discord fishing MMORPG.`),
			links: [{
				rel: "canonical",
				href: `/rods/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./wiki.index-B6XIwLzF.mjs");
var Route$1 = createFileRoute("/wiki/")({
	head: () => ({
		meta: pageMeta("Wiki — Bubble Documentation", "Official Bubble documentation: getting started, commands, energy, fishing, weather, rods, enchants, baits, pets, eggs, market, museum, guilds and quests."),
		links: [{
			rel: "canonical",
			href: "/wiki"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./wiki._slug-f1r9OBW1.mjs");
var Route = createFileRoute("/wiki/$slug")({
	loader: ({ params }) => {
		const entry = wikiBySlug(params.slug);
		if (!entry) throw notFound();
		return { entry };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Article not found — Bubble" }, {
			name: "robots",
			content: "noindex"
		}] };
		const a = loaderData.entry;
		return {
			meta: pageMeta(`${a.title} — Bubble Wiki`, a.summary),
			links: [{
				rel: "canonical",
				href: `/wiki/${params.slug}`
			}]
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
/** Renders `inline code` spans from the plain-text article body. */
var IndexRoute = Route$19.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$20
});
var FaqRoute = Route$18.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$20
});
var FeaturesRoute = Route$17.update({
	id: "/features",
	path: "/features",
	getParentRoute: () => Route$20
});
var LeaderboardRoute = Route$16.update({
	id: "/leaderboard",
	path: "/leaderboard",
	getParentRoute: () => Route$20
});
var PrivacyRoute = Route$15.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$20
});
var TermsRoute = Route$14.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$20
});
var BaitsIndexRoute = Route$13.update({
	id: "/baits/",
	path: "/baits/",
	getParentRoute: () => Route$20
});
var BaitsSlugRoute = Route$12.update({
	id: "/baits/$slug",
	path: "/baits/$slug",
	getParentRoute: () => Route$20
});
var EggsIndexRoute = Route$11.update({
	id: "/eggs/",
	path: "/eggs/",
	getParentRoute: () => Route$20
});
var EggsSlugRoute = Route$10.update({
	id: "/eggs/$slug",
	path: "/eggs/$slug",
	getParentRoute: () => Route$20
});
var EnchantsIndexRoute = Route$9.update({
	id: "/enchants/",
	path: "/enchants/",
	getParentRoute: () => Route$20
});
var EnchantsSlugRoute = Route$8.update({
	id: "/enchants/$slug",
	path: "/enchants/$slug",
	getParentRoute: () => Route$20
});
var FishIndexRoute = Route$7.update({
	id: "/fish/",
	path: "/fish/",
	getParentRoute: () => Route$20
});
var FishSlugRoute = Route$6.update({
	id: "/fish/$slug",
	path: "/fish/$slug",
	getParentRoute: () => Route$20
});
var PetsIndexRoute = Route$5.update({
	id: "/pets/",
	path: "/pets/",
	getParentRoute: () => Route$20
});
var PetsSlugRoute = Route$4.update({
	id: "/pets/$slug",
	path: "/pets/$slug",
	getParentRoute: () => Route$20
});
var RodsIndexRoute = Route$3.update({
	id: "/rods/",
	path: "/rods/",
	getParentRoute: () => Route$20
});
var RodsSlugRoute = Route$2.update({
	id: "/rods/$slug",
	path: "/rods/$slug",
	getParentRoute: () => Route$20
});
var WikiIndexRoute = Route$1.update({
	id: "/wiki/",
	path: "/wiki/",
	getParentRoute: () => Route$20
});
var rootRouteChildren = {
	IndexRoute,
	FaqRoute,
	FeaturesRoute,
	LeaderboardRoute,
	PrivacyRoute,
	TermsRoute,
	BaitsSlugRoute,
	EggsSlugRoute,
	EnchantsSlugRoute,
	FishSlugRoute,
	PetsSlugRoute,
	RodsSlugRoute,
	WikiSlugRoute: Route.update({
		id: "/wiki/$slug",
		path: "/wiki/$slug",
		getParentRoute: () => Route$20
	}),
	BaitsIndexRoute,
	EggsIndexRoute,
	EnchantsIndexRoute,
	FishIndexRoute,
	PetsIndexRoute,
	RodsIndexRoute,
	WikiIndexRoute
};
var routeTree = Route$20._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { Route$6 as a, Route$12 as c, DISCORD_URL as d, INVITE_URL as f, Route$4 as i, fishCountByRarity as l, Route as n, Route$8 as o, Route$2 as r, Route$10 as s, router_exports as t, rosterCounts as u };
