import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as pets } from "./pets-ud1zJYwV.mjs";
import { a as Reveal, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { a as PetCard } from "./cards-DgSr2LGO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pets.index-DXjucaEt.js
var import_jsx_runtime = require_jsx_runtime();
function PetsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Companions",
			title: "Pets",
			description: `${pets.length} companions, hatched from the Common, Rare and Ancient eggs.`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5",
			children: pets.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .03,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PetCard, { pet: p })
			}) }, p.slug))
		})]
	});
}
//#endregion
export { PetsIndex as component };
