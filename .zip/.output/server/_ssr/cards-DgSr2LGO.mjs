import { t as cn } from "./utils-C_uf36nf.mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "../_libs/motion.mjs";
import { i as RarityBadge } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards-DgSr2LGO.js
var import_jsx_runtime = require_jsx_runtime();
function TiltCard({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		whileHover: {
			y: -6,
			rotateX: 2,
			rotateY: -2
		},
		transition: {
			type: "spring",
			stiffness: 260,
			damping: 20
		},
		className: cn("glass group h-full rounded-2xl p-4 transition-shadow hover:shadow-[var(--shadow-glow)]", className),
		style: { transformPerspective: 900 },
		children
	});
}
function TierPill({ tier }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex items-center rounded-full border border-border px-2.5 py-0.5 text-xs font-semibold tracking-wide text-muted-foreground uppercase",
		children: tier
	});
}
function FishCard({ fish }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/fish/$slug",
		params: { slug: fish.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: fish.image,
			alt: fish.name,
			rarity: fish.rarity
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-sm font-bold sm:text-base",
				children: fish.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: fish.rarity })]
		})] })
	});
}
function PetCard({ pet }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/pets/$slug",
		params: { slug: pet.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: pet.image,
			alt: pet.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-3 font-display text-sm font-bold sm:text-base",
			children: pet.name
		})] })
	});
}
function EggCard({ egg }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/eggs/$slug",
		params: { slug: egg.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: egg.image,
			alt: egg.name,
			className: "from-treasure/20"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-3 font-display text-base font-bold",
			children: egg.name
		})] })
	});
}
function RodCard({ rod }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/rods/$slug",
		params: { slug: rod.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: rod.image,
			alt: rod.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-sm font-bold sm:text-base",
				children: rod.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TierPill, { tier: rod.tier })]
		})] })
	});
}
function BaitCard({ bait }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/baits/$slug",
		params: { slug: bait.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: bait.image,
			alt: bait.name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-sm font-bold sm:text-base",
				children: bait.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TierPill, { tier: bait.tier })]
		})] })
	});
}
function EnchantCard({ enchant }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/enchants/$slug",
		params: { slug: enchant.slug },
		className: "block h-full rounded-2xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TiltCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
			src: enchant.image,
			alt: `${enchant.name} enchantment book`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-sm font-bold sm:text-base",
				children: enchant.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TierPill, { tier: `max ${Math.round(enchant.valuePerLevel[2] * 100)}%` })]
		})] })
	});
}
//#endregion
export { PetCard as a, FishCard as i, EggCard as n, RodCard as o, EnchantCard as r, BaitCard as t };
