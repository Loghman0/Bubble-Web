import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as baits } from "./baits-DPjlVlb7.mjs";
import { a as Reveal, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { t as BaitCard } from "./cards-DgSr2LGO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/baits.index-CK_dxobs.js
var import_jsx_runtime = require_jsx_runtime();
var tiers = [
	"Beginner",
	"Journeyman",
	"Master"
];
function BaitsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Gear",
			title: "Baits",
			description: `${baits.length} baits, from a simple worm to magical dust.`
		}), tiers.map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-bold",
				children: tier
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4",
				children: baits.filter((b) => b.tier === tier).map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .04,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BaitCard, { bait: b })
				}) }, b.slug))
			})]
		}, tier))]
	});
}
//#endregion
export { BaitsIndex as component };
