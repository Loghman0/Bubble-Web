import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as baits } from "./baits-BudG6h8S.mjs";
import { n as enchants } from "./enchants-X3Es6ort.mjs";
import { i as pets, n as eggs } from "./pets-ud1zJYwV.mjs";
import { r as rods } from "./rods-B5zxltCO.mjs";
import { T as Anchor, c as PawPrint, f as Fish, g as Coins, i as Sparkles, m as Egg, n as WandSparkles } from "../_libs/lucide-react.mjs";
import { l as fishCountByRarity } from "./router-DaLxecGI.mjs";
import { a as Reveal, i as RarityBadge, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
import { t as OceanBackdrop } from "./OceanBackdrop-A3c4kps6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/features-CYGALHJU.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Currencies. Artwork: `public/assets/currencies/<key>.png`.
*/
var currencies = [
	{
		key: "bubble_coin",
		name: "Bubble Coin",
		image: "/assets/currencies/bubble_coin.png"
	},
	{
		key: "bubble_gem",
		name: "Bubble Gem",
		image: "/assets/currencies/bubble_gem.png"
	},
	{
		key: "ancient_coin",
		name: "Ancient Coin",
		image: "/assets/currencies/ancient_coin.png"
	}
];
var systems = [
	{
		icon: Fish,
		title: "Fishing",
		body: "Cast your line in Discord and work through 107 species spread over nine rarity tiers, from Common all the way to Divine."
	},
	{
		icon: Anchor,
		title: "Rods",
		body: "Nine rods in three brackets: Beginner (Wood, Bamboo, Iron), Journeyman (Steel, Reinforced, Gold) and Master (Coral, Dragon, Cosmic)."
	},
	{
		icon: Sparkles,
		title: "Baits",
		body: "Twelve baits, from worms and crickets up to Starlight Dust and Magical Dust."
	},
	{
		icon: PawPrint,
		title: "Pets",
		body: `${pets.length} companions to collect, including the Otter, Kraken Hatchling, Dragon and Void Wisp.`
	},
	{
		icon: Egg,
		title: "Eggs",
		body: "Three eggs — Common, Rare and Ancient — each a route to a new companion."
	},
	{
		icon: WandSparkles,
		title: "Enchants",
		body: `${enchants.length} rod enchants, from Lucky Catch to Double Hook, each with three upgradeable levels.`
	},
	{
		icon: Coins,
		title: "Currencies",
		body: "Bubble Coins for everyday fishing, Bubble Gems for premium purchases, and the rare Ancient Coin."
	}
];
function FeaturesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, { bubbles: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
					eyebrow: "Gameplay",
					title: "A full fishing MMORPG in a chat window",
					description: "Everything Bubble ships with today, laid out in one place."
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-4 pb-8 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: systems.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .04,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "glass h-full rounded-2xl p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-xl bg-gradient-to-br from-lagoon/30 to-transparent text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, {
									className: "size-5",
									"aria-hidden": true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 font-display text-xl font-bold",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: s.body
							})
						]
					})
				}) }, s.title))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
			"aria-labelledby": "rarities",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "rarities",
				className: "font-display text-2xl font-bold sm:text-3xl",
				children: "Rarity tiers"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "Nine tiers, and the number of species in each."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 flex flex-wrap gap-3",
				children: fishCountByRarity.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "glass flex items-center gap-2 rounded-full py-1.5 pr-4 pl-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: r.rarity }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm tabular-nums text-muted-foreground",
						children: [r.count, " species"]
					})]
				}, r.rarity))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 pb-20 sm:px-6",
			"aria-labelledby": "currencies",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "currencies",
					className: "font-display text-2xl font-bold sm:text-3xl",
					children: "Currencies"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 grid gap-4 sm:grid-cols-3",
					children: currencies.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * .05,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass flex items-center gap-4 rounded-2xl p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-16 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
									src: c.image,
									alt: c.name
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display font-bold",
								children: c.name
							})]
						})
					}) }, c.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-10 text-sm text-muted-foreground",
					children: [
						rods.length,
						" rods · ",
						baits.length,
						" baits · ",
						pets.length,
						" pets · ",
						eggs.length,
						" eggs ·",
						" ",
						enchants.length,
						" enchants"
					]
				})
			]
		})
	] });
}
//#endregion
export { FeaturesPage as component };
