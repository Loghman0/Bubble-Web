import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { n as eggs } from "./pets-zZN8Pgm8.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$4 } from "./router-CBlPtzp6.mjs";
import { a as Reveal, i as RarityBadge } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
import { a as titleCase, n as formatFlat, r as formatPercent } from "./game-format-D6teHOEi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pets._slug-bxWhVCNg.js
var import_jsx_runtime = require_jsx_runtime();
/** Skill categories whose skillValue is a flat stat point rather than a percentage. */
var FLAT_SKILL_CATEGORIES = /* @__PURE__ */ new Set(["luck", "repair"]);
function PetDetail() {
	const { entry: p } = Route$4.useLoaderData();
	const sourceEggs = eggs.filter((e) => e.eligiblePetIds.includes(p.key));
	const skillValueDisplay = FLAT_SKILL_CATEGORIES.has(p.skillCategory) ? formatFlat(p.skillValue) : formatPercent(p.skillValue);
	const rows = [
		["Rarity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: p.rarity }, "rarity")],
		["Unlock Level", p.unlockLevel],
		["Skill", titleCase(p.skill)],
		["Skill Value", skillValueDisplay],
		["Hatches From", sourceEggs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex flex-wrap justify-end gap-2",
			children: sourceEggs.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/eggs/$slug",
				params: { slug: e.slug },
				className: "text-primary hover:underline",
				children: e.name
			}, e.key))
		}) : "—"],
		["In-game id", p.key]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Breadcrumb",
			className: "text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pets",
					className: "hover:text-foreground",
					children: "Pets"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: " / "
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: p.name
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 md:grid-cols-[300px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
				src: p.image,
				alt: p.name
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .08,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-bold sm:text-4xl",
							children: p.name
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-6 grid gap-2 sm:grid-cols-2",
						children: rows.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold",
								children: v
							})]
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 glass rounded-xl px-4 py-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold mb-2",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: p.description
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pets",
								children: "Back to pets"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/eggs",
								children: "View eggs"
							})
						})]
					})
				]
			})]
		})]
	});
}
//#endregion
export { PetDetail as component };
