import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as pets, n as eggs } from "./pets-ud1zJYwV.mjs";
import { a as Reveal, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { n as EggCard } from "./cards-DgSr2LGO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/eggs.index-l9gbxodp.js
var import_jsx_runtime = require_jsx_runtime();
function EggsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Hatching",
			title: "Eggs",
			description: `Three eggs, ${pets.length} possible companions.`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-12 grid gap-4 sm:grid-cols-3",
			children: eggs.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .06,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EggCard, { egg: e })
			}) }, e.slug))
		})]
	});
}
//#endregion
export { EggsIndex as component };
