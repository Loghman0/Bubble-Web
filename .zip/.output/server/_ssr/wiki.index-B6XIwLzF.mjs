import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as wikiCategories, n as wikiArticles } from "./content-CICGCk7H.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Search } from "../_libs/lucide-react.mjs";
import { a as Reveal, n as EmptyState, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wiki.index-B6XIwLzF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WikiIndex() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)(null);
	const results = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return wikiArticles.filter((a) => {
			if (category && a.category !== category) return false;
			if (!q) return true;
			return [
				a.title,
				a.summary,
				a.category,
				...a.tags ?? [],
				...a.sections.map((s) => `${s.heading} ${s.body}`)
			].join(" ").toLowerCase().includes(q);
		});
	}, [query, category]);
	const counts = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const a of wikiArticles) map.set(a.category, (map.get(a.category) ?? 0) + 1);
		return map;
	}, []);
	const grouped = (0, import_react.useMemo)(() => {
		return wikiCategories.map((c) => ({
			category: c,
			items: results.filter((a) => a.category === c)
		})).filter((g) => g.items.length > 0);
	}, [results]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Documentation",
				title: "Bubble Wiki",
				description: "Everything about how the game actually works — mechanics, commands, items and progression, written for players who want the detail."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-8 max-w-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search articles, mechanics or commands",
					"aria-label": "Search the wiki",
					className: "pl-9"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap justify-center gap-2 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryChip, {
					active: category === null,
					onClick: () => setCategory(null),
					children: "All"
				}), wikiCategories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryChip, {
					active: category === c,
					onClick: () => setCategory(c),
					children: c
				}, c))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-10 lg:grid-cols-[240px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Wiki categories",
					className: "hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs font-semibold tracking-widest text-muted-foreground uppercase",
							children: "Categories"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 space-y-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setCategory(null),
								"aria-current": category === null ? "true" : void 0,
								className: cn("flex w-full items-center justify-between rounded-lg px-3 py-1.5 text-left transition-colors", category === null ? "bg-primary/15 font-semibold text-primary" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"),
								children: ["All articles", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs",
									children: wikiArticles.length
								})]
							}) }), wikiCategories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setCategory(c),
								"aria-current": category === c ? "true" : void 0,
								className: cn("flex w-full items-center justify-between gap-2 rounded-lg px-3 py-1.5 text-left transition-colors", category === c ? "bg-primary/15 font-semibold text-primary" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs",
									children: counts.get(c) ?? 0
								})]
							}) }, c))]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: grouped.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No articles found",
					description: "Try a different search term or pick another category."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-12",
					children: grouped.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-bold",
						children: group.category
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-4 sm:grid-cols-2",
						children: group.items.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * .03,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/wiki/$slug",
								params: { slug: a.slug },
								className: "glass block h-full rounded-2xl p-5 transition-transform hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-base font-bold",
										children: a.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground",
										children: a.summary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-xs text-muted-foreground",
										children: [a.sections.length, " sections"]
									})
								]
							})
						}) }, a.slug))
					})] }, group.category))
				}) })]
			})
		]
	});
}
function CategoryChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: cn("rounded-full px-3 py-1.5 text-xs font-medium transition-colors", active ? "bg-primary text-primary-foreground" : "glass text-muted-foreground"),
		children
	});
}
//#endregion
export { WikiIndex as component };
