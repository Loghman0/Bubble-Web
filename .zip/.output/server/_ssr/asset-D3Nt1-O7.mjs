import { n as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { s as rarityGlow } from "./primitives-wvDVhHFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/asset-D3Nt1-O7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Renders a 128x128 game asset.
*
* Drop your artwork into `public/assets/<folder>/<key>.png` and it appears
* automatically. Until the image is decoded — or if it's missing entirely —
* the frame stays a neutral rarity-tinted panel. Deliberately no emoji/glyph
* fallback: a Unicode fish showing through while the real PNG loads looks
* broken.
*/
function GameAsset({ src, alt, rarity, className }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [loaded, setLoaded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setFailed(false);
		setLoaded(false);
	}, [src]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex aspect-square w-full items-center justify-center overflow-hidden rounded-xl border border-border bg-gradient-to-br to-deep/60", rarity ? rarityGlow[rarity] : "from-lagoon/20", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			className: cn("absolute inset-2 rounded-lg bg-foreground/[0.04] shadow-[inset_0_0_24px_rgba(255,255,255,0.05)] transition-opacity duration-300", loaded && !failed ? "opacity-0" : "opacity-100")
		}), failed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			width: 128,
			height: 128,
			loading: "lazy",
			decoding: "async",
			onLoad: () => setLoaded(true),
			onError: () => setFailed(true),
			className: cn("relative size-3/4 object-contain [image-rendering:pixelated] transition-opacity duration-300", loaded ? "opacity-100" : "opacity-0")
		})]
	});
}
//#endregion
export { GameAsset as t };
