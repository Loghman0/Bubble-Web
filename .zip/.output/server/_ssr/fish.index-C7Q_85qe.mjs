import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { n as fish, t as RARITIES } from "./game-BJe2xpyU.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Search } from "../_libs/lucide-react.mjs";
import { a as Reveal, n as EmptyState, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { i as FishCard } from "./cards-DgSr2LGO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fish.index-C7Q_85qe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PER_PAGE = 24;
function FishIndex() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [rarity, setRarity] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("rarity");
	const [page, setPage] = (0, import_react.useState)(1);
	const filtered = (0, import_react.useMemo)(() => {
		return [...fish.filter((f) => f.name.toLowerCase().includes(query.toLowerCase()) && (rarity === "all" || f.rarity === rarity))].sort((a, b) => {
			if (sort === "name") return a.name.localeCompare(b.name);
			if (sort === "rarity-desc") return RARITIES.indexOf(b.rarity) - RARITIES.indexOf(a.rarity) || a.name.localeCompare(b.name);
			return RARITIES.indexOf(a.rarity) - RARITIES.indexOf(b.rarity) || a.name.localeCompare(b.name);
		});
	}, [
		query,
		rarity,
		sort
	]);
	const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
	const current = Math.min(page, pages);
	const visible = filtered.slice((current - 1) * PER_PAGE, current * PER_PAGE);
	const reset = () => setPage(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Encyclopedia",
				title: "Fish Encyclopedia",
				description: `${fish.length} species catalogued across nine rarity tiers. Every entry has its own page.`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: query,
							onChange: (e) => {
								setQuery(e.target.value);
								reset();
							},
							placeholder: "Search species",
							"aria-label": "Search fish species",
							className: "pl-9"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: rarity,
						onValueChange: (v) => {
							setRarity(v);
							reset();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "Filter by rarity",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Rarity" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All rarities"
						}), RARITIES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: r,
							children: r
						}, r))] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: sort,
						onValueChange: setSort,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "Sort results",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Sort" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "rarity",
								children: "Rarity: low to high"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "rarity-desc",
								children: "Rarity: high to low"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "name",
								children: "Name: A to Z"
							})
						] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				"aria-live": "polite",
				children: [filtered.length, " species"]
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Nothing in the net",
					description: "No species match those filters. Try another rarity or search term."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6",
				children: visible.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .015,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FishCard, { fish: f })
				}) }, f.slug))
			}),
			pages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mt-10 flex items-center justify-center gap-2",
				"aria-label": "Pagination",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: current === 1,
						onClick: () => setPage(current - 1),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "px-3 text-sm text-muted-foreground",
						children: [
							"Page ",
							current,
							" of ",
							pages
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						disabled: current === pages,
						onClick: () => setPage(current + 1),
						children: "Next"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-10 text-center text-sm text-muted-foreground",
				children: [
					"Looking for gear instead? Visit the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/rods",
						className: "text-primary underline",
						children: "rod catalogue"
					}),
					"."
				]
			})
		]
	});
}
//#endregion
export { FishIndex as component };
