import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as BookOpen, T as Anchor, a as Ship, c as PawPrint, f as Fish, i as Sparkles, m as Egg, n as WandSparkles, w as ArrowRight } from "../_libs/lucide-react.mjs";
import { d as DISCORD_URL, f as INVITE_URL, l as fishCountByRarity, u as rosterCounts } from "./router-DaLxecGI.mjs";
import { t as motion } from "../_libs/motion.mjs";
import { a as Reveal, i as RarityBadge, o as StatCard } from "./primitives-wvDVhHFR.mjs";
import { t as OceanBackdrop } from "./OceanBackdrop-A3c4kps6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-3VziWZtD.js
var import_jsx_runtime = require_jsx_runtime();
var pillars = [
	{
		icon: Fish,
		title: "Fish Encyclopedia",
		body: `${rosterCounts.fish} species across ${rosterCounts.rarities} rarity tiers, from Common to Divine.`,
		to: "/fish"
	},
	{
		icon: Anchor,
		title: "Rods",
		body: `${rosterCounts.rods} rods split into Beginner, Journeyman and Master tiers.`,
		to: "/rods"
	},
	{
		icon: Sparkles,
		title: "Baits",
		body: `${rosterCounts.baits} baits, from a simple worm to magical dust.`,
		to: "/baits"
	},
	{
		icon: PawPrint,
		title: "Pets",
		body: `${rosterCounts.pets} companions to collect and bring along on every cast.`,
		to: "/pets"
	},
	{
		icon: Egg,
		title: "Eggs",
		body: `${rosterCounts.eggs} eggs: Common, Rare and Ancient.`,
		to: "/eggs"
	},
	{
		icon: WandSparkles,
		title: "Enchants",
		body: `${rosterCounts.enchants} rod enchants, each with 3 upgradeable levels.`,
		to: "/enchants"
	},
	{
		icon: BookOpen,
		title: "Wiki",
		body: "Short, factual guides to every system in the game.",
		to: "/wiki"
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, { bubbles: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 py-24 text-center sm:px-6 sm:py-32",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: {
							opacity: 0,
							scale: .9
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						transition: {
							duration: .6,
							ease: [
								.22,
								1,
								.36,
								1
							]
						},
						className: "mx-auto flex size-20 items-center justify-center rounded-3xl bg-gradient-to-br from-lagoon to-primary shadow-[var(--shadow-glow)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ship, {
							className: "size-10 text-primary-foreground",
							"aria-hidden": true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h1, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .6,
							delay: .1
						},
						className: "mt-8 font-display text-4xl font-extrabold text-balance sm:text-6xl lg:text-7xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gradient-ocean",
							children: "Bubble"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .6,
							delay: .2
						},
						className: "mx-auto mt-5 max-w-2xl text-lg text-pretty text-muted-foreground sm:text-xl",
						children: "A cozy fishing MMORPG that lives inside your Discord server. Cast a line, upgrade your gear, hatch a companion, and complete the collection."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .6,
							delay: .3
						},
						className: "mt-9 flex flex-wrap justify-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: INVITE_URL,
									target: "_blank",
									rel: "noreferrer",
									children: ["Invite Bubble ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
										className: "size-4",
										"aria-hidden": true
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/fish",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fish, {
										className: "size-4",
										"aria-hidden": true
									}), " Fish Encyclopedia"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/wiki",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
										className: "size-4",
										"aria-hidden": true
									}), " Wiki"]
								})
							})
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
			"aria-labelledby": "systems",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "systems",
				className: "font-display text-3xl font-bold sm:text-4xl",
				children: "Everything in the game, catalogued"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted-foreground",
				children: "A read-only reference for Bubble's content. Browse it here, play it in Discord."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: pillars.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .04,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: f.to,
						className: "glass block h-full rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-xl bg-gradient-to-br from-lagoon/30 to-transparent text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, {
									className: "size-5",
									"aria-hidden": true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-lg font-bold",
								children: f.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: f.body
							})
						]
					})
				}) }, f.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden border-y border-border/60 py-20",
			"aria-labelledby": "roster",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, { bubbles: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "roster",
						className: "font-display text-3xl font-bold sm:text-4xl",
						children: "The collection"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6",
						children: [
							{
								label: "Fish species",
								value: rosterCounts.fish
							},
							{
								label: "Rods",
								value: rosterCounts.rods
							},
							{
								label: "Baits",
								value: rosterCounts.baits
							},
							{
								label: "Pets",
								value: rosterCounts.pets
							},
							{
								label: "Eggs",
								value: rosterCounts.eggs
							},
							{
								label: "Enchants",
								value: rosterCounts.enchants
							}
						].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * .05,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: s.label,
								value: s.value
							})
						}, s.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-10 flex flex-wrap gap-3",
						children: fishCountByRarity.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "glass flex items-center gap-2 rounded-full py-1.5 pr-4 pl-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: r.rarity }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm tabular-nums text-muted-foreground",
								children: [r.count, " species"]
							})]
						}, r.rarity))
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative isolate overflow-hidden rounded-3xl border border-border p-10 text-center sm:p-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, { bubbles: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-bold text-balance sm:text-4xl",
							children: "Your server is one cast away"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-3 max-w-xl text-muted-foreground",
							children: "Free to add, free to play. Bring Bubble to your Discord and start the collection."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 flex flex-wrap justify-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: INVITE_URL,
									target: "_blank",
									rel: "noreferrer",
									children: ["Invite Bubble ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
										className: "size-4",
										"aria-hidden": true
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: DISCORD_URL,
									target: "_blank",
									rel: "noreferrer",
									children: "Join our Discord"
								})
							})]
						})
					]
				})]
			}) })
		})
	] });
}
//#endregion
export { Home as component };
