import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as enchants } from "./enchants-X3Es6ort.mjs";
import { a as Reveal, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { r as EnchantCard } from "./cards-DgSr2LGO.mjs";
import { t as OceanBackdrop } from "./OceanBackdrop-A3c4kps6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/enchants.index-G6Ye8rCB.js
var import_jsx_runtime = require_jsx_runtime();
function EnchantsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate overflow-hidden py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OceanBackdrop, { bubbles: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto max-w-5xl px-4 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Rod Upgrades",
				title: "Enchants",
				description: `${enchants.length} enchants for Journeyman and Master rods. Each one has 3 levels — open an enchant to see every level's book and bonus.`
			})
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 pb-24 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-2 gap-4 sm:grid-cols-3",
			children: enchants.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .04,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnchantCard, { enchant: e })
			}) }, e.slug))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 text-sm text-muted-foreground",
			children: "Enchants aren't sold in the shop — find them in treasure chests, guild raid rewards, high-level quest rewards, or trade Ancient Museum Coins for one at the Museum Shop. A rod can hold as many enchants at once as it has enchant slots, and never the same enchant twice."
		})]
	})] });
}
//#endregion
export { EnchantsPage as component };
