import { n as __toESM } from "../_runtime.mjs";
import { n as useReducedMotion } from "../_libs/framer-motion+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/OceanBackdrop-A3c4kps6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
	const [isMobile, setIsMobile] = import_react.useState(void 0);
	import_react.useEffect(() => {
		const mql = window.matchMedia(`(max-width: 767px)`);
		const onChange = () => {
			setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		};
		mql.addEventListener("change", onChange);
		setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		return () => mql.removeEventListener("change", onChange);
	}, []);
	return !!isMobile;
}
/**
* Decorative animated ocean layer: caustics, depth gradient, drifting bubbles.
* Bubbles only — no swimming silhouettes.
*/
function OceanBackdrop({ bubbles = 24 }) {
	const reduced = useReducedMotion();
	const isMobile = useIsMobile();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const count = !mounted || reduced ? 0 : isMobile ? Math.ceil(bubbles / 2) : bubbles;
	const items = (0, import_react.useMemo)(() => Array.from({ length: count }, (_, i) => {
		const r = (n) => (Math.sin((i + 1) * n) + 1) / 2;
		return {
			left: Math.round(r(12.9898) * 100),
			size: 4 + Math.round(r(78.233) * 22),
			delay: Math.round(r(43.111) * 220) / 10,
			duration: 18 + Math.round(r(93.989) * 160) / 10,
			drift: Math.round((r(27.42) - .5) * 90),
			opacity: .25 + r(11.7) * .45
		};
	}), [count]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-hidden": true,
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 surface-abyss" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-40 mix-blend-screen",
				style: {
					background: "radial-gradient(60% 45% at 20% 0%, color-mix(in oklab, var(--lagoon) 45%, transparent), transparent 70%), radial-gradient(50% 40% at 85% 10%, color-mix(in oklab, var(--treasure) 25%, transparent), transparent 70%)",
					animation: reduced ? void 0 : "caustics-shift 14s ease-in-out infinite"
				}
			}),
			items.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-[-12vh] rounded-full border border-foam/20 bg-foam/10",
				style: {
					left: `${b.left}%`,
					width: b.size,
					height: b.size,
					opacity: b.opacity,
					["--drift"]: `${b.drift}px`,
					animation: `bubble-rise ${b.duration}s linear ${b.delay}s infinite`
				}
			}, i))
		]
	});
}
//#endregion
export { OceanBackdrop as t };
