import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Route$12 } from "./router-CBlPtzp6.mjs";
import { a as Reveal } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
import { r as formatPercent } from "./game-format-D6teHOEi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/baits._slug-ac_eNRSX.js
var import_jsx_runtime = require_jsx_runtime();
function BaitDetail() {
	const { entry: b } = Route$12.useLoaderData();
	const mult = (m) => m === 1 ? "No effect" : formatPercent(m - 1);
	const rows = [
		["Tier", b.tier],
		["Price", b.price > 0 ? `${b.price.toLocaleString()} ${b.currency}` : "Free"],
		["Rare+ Chance", mult(b.rareChanceMult)],
		["Legendary+ Chance", mult(b.legendaryChanceMult)],
		["Fish Weight", mult(b.weightMult)],
		["Treasure Chance", b.treasureChanceAdd > 0 ? formatPercent(b.treasureChanceAdd) : "No effect"],
		["In-game id", b.key]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Breadcrumb",
			className: "text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/baits",
					className: "hover:text-foreground",
					children: "Baits"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: " / "
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: b.name
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 md:grid-cols-[300px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
				src: b.image,
				alt: b.name
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .08,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-bold sm:text-4xl",
						children: b.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-6 grid gap-2 sm:grid-cols-2",
						children: rows.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold",
								children: v
							})]
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 glass rounded-xl px-4 py-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold mb-2",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: b.description
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/baits",
								children: "Back to baits"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/rods",
								children: "Browse rods"
							})
						})]
					})
				]
			})]
		})]
	});
}
//#endregion
export { BaitDetail as component };
