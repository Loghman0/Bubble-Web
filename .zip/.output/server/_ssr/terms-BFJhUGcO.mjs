import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { r as PageHeader } from "./primitives-wvDVhHFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-BFJhUGcO.js
var import_jsx_runtime = require_jsx_runtime();
var sections = [
	["Acceptance", "By adding Bubble to a server or running any Bubble command, you agree to these terms and to Discord's own Terms of Service."],
	["Acceptable use", "Do not automate commands, exploit bugs, use alternate accounts to farm rewards, or harass other players. Report exploits in the support server instead of using them."],
	["Accounts and progress", "Progress belongs to a Discord account, not a server. We may reset progress obtained through exploits or automation."],
	["Virtual items", "Coins, gems, ancient coins, fish, pets, and rods have no real-world value, cannot be exchanged for money, and may be rebalanced or removed."],
	["Availability", "Bubble is provided as-is with no uptime guarantee. Features may change, pause, or be retired."],
	["Termination", "We may restrict access to Bubble for any account that breaks these terms."],
	["Liability", "To the maximum extent permitted by law, Bubble and its maintainers are not liable for lost progress or damages arising from use of the bot."],
	["Contact", "Questions about these terms: hello@bubble.gg or the support server."]
];
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Legal",
			title: "Terms of Service",
			description: "Last updated 28 July 2026."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 space-y-8",
			children: sections.map(([h, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-bold",
				children: h
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: b
			})] }, h))
		})]
	});
}
//#endregion
export { TermsPage as component };
