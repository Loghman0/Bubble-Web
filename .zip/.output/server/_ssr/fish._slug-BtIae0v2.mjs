import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as baitBySlug } from "./baits-BudG6h8S.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$6 } from "./router-DaLxecGI.mjs";
import { a as Reveal, i as RarityBadge } from "./primitives-wvDVhHFR.mjs";
import { t as GameAsset } from "./asset-D3Nt1-O7.mjs";
import { a as titleCase, i as formatRange, t as formatCondition } from "./game-format-D6teHOEi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fish._slug-BtIae0v2.js
var import_jsx_runtime = require_jsx_runtime();
function FishDetail() {
	const { entry: f } = Route$6.useLoaderData();
	const bait = f.requiredBait ? baitBySlug(f.requiredBait.replace(/_/g, "-")) : null;
	const rows = [
		["Rarity", f.rarity],
		["Habitat", titleCase(f.habitat)],
		["Selling Price", f.price ? `${f.price.toLocaleString()} coins` : "—"],
		["Weight", formatRange(f.weight, "kg")],
		["Length", formatRange(f.length, "cm")],
		["Season", formatCondition(f.season)],
		["Weather", formatCondition(f.weather)],
		["Active Time", formatCondition(f.activeTime)],
		["Difficulty", `${f.difficulty} / 10`],
		["Required Rod Level", f.requiredRodLevel],
		["Required Bait", bait ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/baits/$slug",
			params: { slug: bait.slug },
			className: "text-primary hover:underline",
			children: bait.name
		}) : "None"],
		["Fishing XP", f.xp.toLocaleString()],
		["Museum Value", f.museumValue.toLocaleString()],
		...typeof f.minLuck === "number" ? [["Minimum Luck", f.minLuck]] : [],
		...typeof f.minCombo === "number" ? [["Minimum Combo Streak", `${f.minCombo}x`]] : [],
		["In-game id", f.key]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Breadcrumb",
			className: "text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/fish",
					className: "hover:text-foreground",
					children: "Fish Encyclopedia"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: " / "
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground",
					children: f.name
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-8 md:grid-cols-[300px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameAsset, {
				src: f.image,
				alt: f.name,
				rarity: f.rarity
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: .08,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-bold sm:text-4xl",
							children: f.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RarityBadge, { rarity: f.rarity })]
					}),
					f.hidden && f.discoveryCondition ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 glass rounded-xl border border-primary/30 px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-primary",
							children: "Hidden species — "
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: ["stays out of the public encyclopedia until first discovered. ", f.discoveryCondition]
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 font-display text-lg font-bold",
						children: "Details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-3 grid gap-2 sm:grid-cols-2",
						children: rows.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass flex justify-between gap-4 rounded-xl px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold",
								children: v
							})]
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 glass rounded-xl px-4 py-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold mb-2",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: f.description
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/fish",
								children: "Back to encyclopedia"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "ghost",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/rods",
								children: "Browse rods"
							})
						})]
					})
				]
			})]
		})]
	});
}
//#endregion
export { FishDetail as component };
