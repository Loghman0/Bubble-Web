import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as rodTiers, r as rods } from "./rods-DB3oDwAf.mjs";
import { a as Reveal, r as PageHeader } from "./primitives-wvDVhHFR.mjs";
import { o as RodCard } from "./cards-DgSr2LGO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rods.index-x3cLh10I.js
var import_jsx_runtime = require_jsx_runtime();
function RodsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Gear",
			title: "Rods",
			description: "Nine rods across three progression tiers. Every rod has its own page."
		}), rodTiers.map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-bold",
				children: tier
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3",
				children: rods.filter((r) => r.tier === tier).map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .04,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RodCard, { rod: r })
				}) }, r.slug))
			})]
		}, tier))]
	});
}
//#endregion
export { RodsIndex as component };
