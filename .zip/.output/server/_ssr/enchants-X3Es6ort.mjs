//#region node_modules/.nitro/vite/services/ssr/assets/enchants-X3Es6ort.js
/**
* Rod enchants, mirrored 1:1 from the Bubble Discord bot's `data/enchants.js`.
*
* Enchants apply to a specific owned rod instance, not to the player
* globally — switching rods means starting over on that rod's enchants.
* A rod can hold at most `Rod.enchantSlots` enchants at once (0 on Wood/
* Bamboo, scaling up to 9 on Cosmic), and the same enchant can't be applied
* twice to one rod. Each enchant has 3 levels (I/II/III); `valuePerLevel`
* gives the bonus at each level. Enchants are NOT sold in the shop — they
* come from treasure chests, guild raid rewards, high-level quest rewards,
* and the Museum Shop (bought with Ancient Museum Coins).
*/
var ENCHANT_DATA = Object.fromEntries([
	{
		id: "lucky_catch",
		name: "Lucky Catch",
		emoji: "🍀",
		description: "Increases the chance of rolling a rare-or-better fish.",
		appliesTo: "rarity_roll",
		valuePerLevel: [
			.02,
			.04,
			.07
		]
	},
	{
		id: "treasure_hunter",
		name: "Treasure Hunter",
		emoji: "🗺️",
		description: "Increases the chance of finding a treasure chest.",
		appliesTo: "treasure_event",
		valuePerLevel: [
			.01,
			.02,
			.035
		]
	},
	{
		id: "gem_hunter",
		name: "Gem Hunter",
		emoji: "💎",
		description: "Small chance to find a few bonus gems on any catch.",
		appliesTo: "gem_bonus",
		valuePerLevel: [
			.01,
			.02,
			.035
		]
	},
	{
		id: "efficient_line",
		name: "Efficient Line",
		emoji: "🧵",
		description: "Reduces the energy cost of casting.",
		appliesTo: "energy_cost",
		valuePerLevel: [
			.05,
			.1,
			.15
		]
	},
	{
		id: "experienced_angler",
		name: "Experienced Angler",
		emoji: "📘",
		description: "Increases fishing XP earned per catch.",
		appliesTo: "xp_gain",
		valuePerLevel: [
			.05,
			.1,
			.18
		]
	},
	{
		id: "coin_blessing",
		name: "Coin Blessing",
		emoji: "🪙",
		description: "Increases coins earned when selling fish.",
		appliesTo: "sell_price",
		valuePerLevel: [
			.04,
			.08,
			.14
		]
	},
	{
		id: "museum_instinct",
		name: "Museum Instinct",
		emoji: "🏛️",
		description: "Increases the chance of finding fish valuable to the Museum.",
		appliesTo: "museum_bias",
		valuePerLevel: [
			.03,
			.06,
			.1
		]
	},
	{
		id: "double_hook",
		name: "Double Hook",
		emoji: "🪝",
		description: "Small chance to catch two fish in a single cast.",
		appliesTo: "double_catch",
		valuePerLevel: [
			.02,
			.035,
			.05
		]
	}
].map((e) => [e.id, e]));
var enchants = Object.values(ENCHANT_DATA).map((e) => ({
	key: e.id,
	slug: e.id.replace(/_/g, "-"),
	name: e.name,
	emoji: e.emoji,
	description: e.description,
	appliesTo: e.appliesTo,
	valuePerLevel: e.valuePerLevel,
	image: `/assets/enchantments/${e.id}.png`,
	levelImages: [
		`/assets/enchantments/${e.id}.png`,
		`/assets/enchantments/${e.id}.png`,
		`/assets/enchantments/${e.id}.png`
	]
}));
var enchantBySlug = (slug) => enchants.find((e) => e.slug === slug);
//#endregion
export { enchants as n, enchantBySlug as t };
