import { n as __toESM } from "../_runtime.mjs";
import { i as performance_default, n as useReducedMotion, t as useInView } from "../_libs/framer-motion+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as motion } from "../_libs/motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/primitives-wvDVhHFR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reveal({ children, delay = 0, className }) {
	const reduced = useReducedMotion();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		className,
		initial: reduced ? false : {
			opacity: 0,
			y: 18
		},
		whileInView: {
			opacity: 1,
			y: 0
		},
		viewport: {
			once: true,
			margin: "-60px"
		},
		transition: {
			duration: .5,
			delay,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		children
	});
}
function AnimatedCounter({ value, suffix = "", decimals = 0 }) {
	const ref = (0, import_react.useRef)(null);
	const inView = useInView(ref, {
		once: true,
		margin: "-40px"
	});
	const reduced = useReducedMotion();
	const [display, setDisplay] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!inView) return;
		if (reduced) {
			setDisplay(value);
			return;
		}
		const duration = 1400;
		const start = performance_default.now();
		let frame = 0;
		const tick = (now) => {
			const p = Math.min(1, (now - start) / duration);
			const eased = 1 - Math.pow(1 - p, 3);
			setDisplay(value * eased);
			if (p < 1) frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [
		inView,
		value,
		reduced
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		className: "tabular-nums",
		children: [display.toLocaleString(void 0, {
			maximumFractionDigits: decimals,
			minimumFractionDigits: decimals
		}), suffix]
	});
}
var rarityClass = {
	Common: "text-rarity-common border-rarity-common/40 bg-rarity-common/10",
	Uncommon: "text-rarity-uncommon border-rarity-uncommon/40 bg-rarity-uncommon/10",
	Rare: "text-rarity-rare border-rarity-rare/40 bg-rarity-rare/10",
	Epic: "text-rarity-epic border-rarity-epic/40 bg-rarity-epic/10",
	Legendary: "text-rarity-legendary border-rarity-legendary/40 bg-rarity-legendary/10",
	Mythic: "text-rarity-mythic border-rarity-mythic/40 bg-rarity-mythic/10",
	Ancient: "text-rarity-ancient border-rarity-ancient/40 bg-rarity-ancient/10",
	Celestial: "text-rarity-celestial border-rarity-celestial/40 bg-rarity-celestial/10",
	Divine: "text-rarity-divine border-rarity-divine/40 bg-rarity-divine/10"
};
var rarityGlow = {
	Common: "from-rarity-common/25",
	Uncommon: "from-rarity-uncommon/25",
	Rare: "from-rarity-rare/30",
	Epic: "from-rarity-epic/30",
	Legendary: "from-rarity-legendary/35",
	Mythic: "from-rarity-mythic/40",
	Ancient: "from-rarity-ancient/35",
	Celestial: "from-rarity-celestial/40",
	Divine: "from-rarity-divine/40"
};
function RarityBadge({ rarity, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold tracking-wide uppercase", rarityClass[rarity], className),
		children: rarity
	});
}
function StatCard({ label, value, suffix, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-2xl p-5 transition-transform duration-300 hover:-translate-y-1",
		children: [
			icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 text-primary",
				children: icon
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-2xl font-bold text-foreground sm:text-3xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatedCounter, {
					value,
					suffix
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-sm text-muted-foreground",
				children: label
			})
		]
	});
}
function EmptyState({ title, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass flex flex-col items-center rounded-2xl px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-4xl",
				"aria-hidden": true,
				children: "🫧"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-lg font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-sm text-sm text-muted-foreground",
				children: description
			})
		]
	});
}
function PageHeader({ eyebrow, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mx-auto max-w-3xl text-center",
		children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.2em] text-primary uppercase",
				children: eyebrow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-3xl font-bold text-balance sm:text-5xl",
				children: title
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base text-pretty text-muted-foreground sm:text-lg",
				children: description
			}) : null,
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children
			}) : null
		]
	});
}
//#endregion
export { Reveal as a, RarityBadge as i, EmptyState as n, StatCard as o, PageHeader as r, rarityGlow as s, AnimatedCounter as t };
