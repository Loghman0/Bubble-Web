//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DKuL1o3H.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/__root.tsx",
		children: [
			"/",
			"/faq",
			"/features",
			"/leaderboard",
			"/privacy",
			"/terms",
			"/baits/$slug",
			"/eggs/$slug",
			"/enchants/$slug",
			"/fish/$slug",
			"/pets/$slug",
			"/rods/$slug",
			"/wiki/$slug",
			"/baits/",
			"/eggs/",
			"/enchants/",
			"/fish/",
			"/pets/",
			"/rods/",
			"/wiki/"
		],
		preloads: [
			"/assets/index-CfKhPtpc.js",
			"/assets/utils-BFmSEvC8.js",
			"/assets/react-dom-BRNPAwij.js",
			"/assets/link-DINiT5xD.js",
			"/assets/createLucideIcon-Cgt1V5aE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CfKhPtpc.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CWOfJ8Kg.js",
			"/assets/wand-sparkles-BMfJkCsw.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/faq": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-BUBpM1Vw.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/features": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/features.tsx",
		children: void 0,
		preloads: [
			"/assets/features-7XGsRdkN.js",
			"/assets/wand-sparkles-BMfJkCsw.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/leaderboard": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/leaderboard.tsx",
		children: void 0,
		preloads: [
			"/assets/leaderboard-BXd5vxOz.js",
			"/assets/select-DAy2T8SN.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DtYAFEce.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/terms": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-uZYipadI.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/baits/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/baits.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/baits._slug-DsMqmNtb.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/eggs/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/eggs.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/eggs._slug-JGM56t3E.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js"
		]
	},
	"/enchants/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/enchants.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/enchants._slug-DqRYza-1.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/fish/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/fish.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/fish._slug-B_UdyhdT.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/pets/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/pets.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/pets._slug-AtuaFtfR.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/rods/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/rods.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/rods._slug-BmmfoqA-.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js"
		]
	},
	"/wiki/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/wiki.$slug.tsx",
		children: void 0,
		preloads: ["/assets/wiki._slug-CyEAChZ3.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/baits/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/baits.index.tsx",
		children: void 0,
		preloads: [
			"/assets/baits.index-THu2PnB0.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/eggs/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/eggs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/eggs.index-Cor7QX_d.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/enchants/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/enchants.index.tsx",
		children: void 0,
		preloads: [
			"/assets/enchants.index-DZ7_W9PV.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/fish/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/fish.index.tsx",
		children: void 0,
		preloads: [
			"/assets/fish.index-BlgmBZ2L.js",
			"/assets/select-DAy2T8SN.js",
			"/assets/input-C5wCZI5w.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/pets/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/pets.index.tsx",
		children: void 0,
		preloads: [
			"/assets/pets.index-B7nlrC0X.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/rods/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/rods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/rods.index-BpfcrNRw.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/wiki/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/wiki.index.tsx",
		children: void 0,
		preloads: [
			"/assets/wiki.index-DJnSYjPF.js",
			"/assets/input-C5wCZI5w.js",
			"/assets/primitives-DzUDVYA5.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
