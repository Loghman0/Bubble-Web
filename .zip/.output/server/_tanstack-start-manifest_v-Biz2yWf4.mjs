//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Biz2yWf4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/__root.tsx",
		children: [
			"/",
			"/faq",
			"/features",
			"/leaderboard",
			"/privacy",
			"/terms",
			"/baits/$slug",
			"/eggs/$slug",
			"/enchants/$slug",
			"/fish/$slug",
			"/pets/$slug",
			"/rods/$slug",
			"/wiki/$slug",
			"/baits/",
			"/eggs/",
			"/enchants/",
			"/fish/",
			"/pets/",
			"/rods/",
			"/wiki/"
		],
		preloads: [
			"/assets/index-CcpPu-DY.js",
			"/assets/utils-BFmSEvC8.js",
			"/assets/react-dom-BRNPAwij.js",
			"/assets/link-DINiT5xD.js",
			"/assets/createLucideIcon-Cgt1V5aE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CcpPu-DY.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-3YsVXmlY.js",
			"/assets/wand-sparkles-BMfJkCsw.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/faq": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-BLeCM6CC.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/features": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/features.tsx",
		children: void 0,
		preloads: [
			"/assets/features-B5rn2qQB.js",
			"/assets/wand-sparkles-BMfJkCsw.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/leaderboard": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/leaderboard.tsx",
		children: void 0,
		preloads: [
			"/assets/leaderboard-DK0A7Wvv.js",
			"/assets/select-D-SZqp4v.js",
			"/assets/sparkles-C3WlmzSQ.js",
			"/assets/primitives-DzUDVYA5.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DtYAFEce.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/terms": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-uZYipadI.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/baits/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/baits.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/baits._slug-WRxHP5co.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/eggs/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/eggs.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/eggs._slug-C4uD0H_V.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js"
		]
	},
	"/enchants/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/enchants.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/enchants._slug-DSzh34Cq.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/fish/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/fish.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/fish._slug-BeNWysLz.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/pets/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/pets.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/pets._slug-CxJksiZm.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js",
			"/assets/game-format-C7SNMZ2d.js"
		]
	},
	"/rods/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/rods.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/rods._slug-YwaguX_N.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/asset-42-JXiO3.js"
		]
	},
	"/wiki/$slug": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/wiki.$slug.tsx",
		children: void 0,
		preloads: ["/assets/wiki._slug-DSFg10vG.js", "/assets/primitives-DzUDVYA5.js"]
	},
	"/baits/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/baits.index.tsx",
		children: void 0,
		preloads: [
			"/assets/baits.index-CfHsUK2Q.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/eggs/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/eggs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/eggs.index-Ciwbt2lp.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/enchants/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/enchants.index.tsx",
		children: void 0,
		preloads: [
			"/assets/enchants.index-D--HBVEj.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js",
			"/assets/OceanBackdrop-CGeS_onY.js"
		]
	},
	"/fish/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/fish.index.tsx",
		children: void 0,
		preloads: [
			"/assets/fish.index-BaUagaH8.js",
			"/assets/select-D-SZqp4v.js",
			"/assets/input-C5wCZI5w.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/pets/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/pets.index.tsx",
		children: void 0,
		preloads: [
			"/assets/pets.index-BCcdXS-a.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/rods/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/rods.index.tsx",
		children: void 0,
		preloads: [
			"/assets/rods.index-BbL4jMt3.js",
			"/assets/primitives-DzUDVYA5.js",
			"/assets/cards-CShZXPtU.js"
		]
	},
	"/wiki/": {
		filePath: "C:/Users/User/Desktop/Projects/Bubble/website/src/routes/wiki.index.tsx",
		children: void 0,
		preloads: [
			"/assets/wiki.index-DyPoWFiX.js",
			"/assets/input-C5wCZI5w.js",
			"/assets/primitives-DzUDVYA5.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
